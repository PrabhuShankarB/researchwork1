"""Sub-work 1: all experiments on the full 14-day trace."""
import json, time
import numpy as np
from sw1.sim import load, reserve_base, evaluate, POLICIES, D
from sw1.offline_lp import offline_bound_realised
from sw1.qkd_link import decoy_key_rate

RES = "/home/claude/hema/results"
L_MAIN = 140.0
t_start = time.time()
regs, A = load(10, None)
qb = reserve_base(A)
TR = regs.index("iic")          # region with the largest T1 volume, used for time-series traces
out = {"regions": regs, "trace_region": "iic", "L_main": L_MAIN, "minutes": int(A["writes"].shape[1])}


def strip(r):
    return {k: v for k, v in r.items() if k not in ("trace", "real")}


# A) main comparison, 3 seeds
out["main"] = []
for p in POLICIES:
    for s in (1, 2, 3):
        r = evaluate(A, qb, L_MAIN, p, seed=s, tr=TR, return_raw=(s == 1))
        if s == 1 and p in ("Proposed", "FCFS (ETSI 014)", "Static split"):
            tr = r["trace"]
            M = tr.shape[0] // 60
            out.setdefault("trace_minute", {})[p] = {
                "pool_bits": tr[:M * 60, 0].reshape(M, 60).mean(1).tolist(),
                "reserve_bits": tr[:M * 60, 1].reshape(M, 60).mean(1).tolist(),
                "l3_arrival_bps": tr[:M * 60, 2].reshape(M, 60).mean(1).tolist(),
                "t2_arrival_bps": tr[:M * 60, 3].reshape(M, 60).mean(1).tolist()}
        if s == 1 and p == "Proposed":
            out["offline_main"] = offline_bound_realised(A, r["real"], float(decoy_key_rate(L_MAIN)[0]))
        out["main"].append(strip(r))
    print("main", p, round(time.time() - t_start), "s", flush=True)

# B) distance sweep
out["distance"] = []
for L in (40.0, 60.0, 80.0, 100.0, 120.0, 140.0, 160.0, 180.0, 200.0):
    for p in ("Proposed", "Proposed w/o TKPF", "FCFS (ETSI 014)", "Static split"):
        r = evaluate(A, qb, L, p, seed=1, return_raw=(p == "Proposed"))
        if p == "Proposed":
            b = offline_bound_realised(A, r["real"], float(decoy_key_rate(L)[0]))
            out["distance"].append({"policy": "Offline optimum", "L_km": L, **b})
        out["distance"].append(strip(r))
    print("distance", L, round(time.time() - t_start), "s", flush=True)

# C) sensitivity at L_MAIN (Proposed, FCFS reference where meaningful)
out["sens"] = []
for B in (60.0, 300.0, 600.0, 1800.0, 3600.0):
    for p in ("Proposed", "FCFS (ETSI 014)"):
        out["sens"].append({"factor": "Bmax_s", "value": B, **strip(evaluate(A, qb, L_MAIN, p, Bmax_s=B))})
for H in (30.0, 60.0, 120.0, 300.0, 600.0):
    out["sens"].append({"factor": "H", "value": H, **strip(evaluate(A, qb, L_MAIN, "Proposed", H=H))})
for q in (0.90, 0.95, 0.99):
    qq = reserve_base(A, q=q)
    out["sens"].append({"factor": "quantile", "value": q, **strip(evaluate(A, qq, L_MAIN, "Proposed"))})
for ks in (0.5, 1.0, 2.0):
    for p in ("Proposed", "FCFS (ETSI 014)", "Static split"):
        out["sens"].append({"factor": "key_scale", "value": ks, **strip(evaluate(A, qb, L_MAIN, p, key_scale=ks))})
print("sens", round(time.time() - t_start), "s", flush=True)

# D) defer-versus-downgrade trade-off (maximum T2 wait W2)
out["defer"] = []
for L in (60.0, 100.0, 140.0):
    for W in (0, 5, 10, 20, 30, 45, 60):
        for p in ("Proposed", "FCFS (ETSI 014)"):
            out["defer"].append(strip(evaluate(A, qb, L, p, W2=W)))
print("defer", round(time.time() - t_start), "s", flush=True)

out["runtime_s"] = time.time() - t_start
json.dump(out, open(f"{RES}/sw1_results.json", "w"))
print("done", out["offline_main"], round(out["runtime_s"]), "s")
