"""Build the Sub-work 1 manuscript (Elsevier review format) from results files."""
import json, sys
import numpy as np
from scipy import stats
sys.path.insert(0, "/home/claude/hema/sw1/paper")
from refs import REFS
from docx_tools import Doc

RES = "/home/claude/hema/results"
FIG = "/home/claude/hema/sw1/figs"
d = json.load(open(f"{RES}/sw1_results.json"))
q = json.load(open(f"{RES}/sw1_qkd_link.json"))
dem = json.load(open(f"{RES}/sw1_demand_summary.json"))
tr = json.load(open("/home/claude/data/processed/trace_summary.json"))

# ---------------- numbers used in the text ----------------
def M(p, k, f=np.mean):
    return f([r[k] for r in d["main"] if r["policy"] == p])
def S(p, k):
    return np.std([r[k] for r in d["main"] if r["policy"] == p])
def pct(x, n=1):
    return f"{100 * x:.{n}f}"
def paired(p, k):
    a = np.array([r[k] for r in sorted([r for r in d["main"] if r["policy"] == "Proposed"], key=lambda r: r["seed"])])
    b = np.array([r[k] for r in sorted([r for r in d["main"] if r["policy"] == p], key=lambda r: r["seed"])])
    df = a - b; se = df.std(ddof=1) / np.sqrt(len(df)); t = stats.t.ppf(0.975, len(df) - 1)
    return df.mean(), df.mean() - t * se, df.mean() + t * se
def dist(p, L, k="otp_cov_T1"):
    return [r for r in d["distance"] if r["policy"] == p and r["L_km"] == L][0][k]
def sens(f, v, p, k="otp_cov_T1"):
    return [r for r in d["sens"] if r["factor"] == f and r["value"] == v and r["policy"] == p][0][k]
def defer(L, W, p, k):
    return [r for r in d["defer"] if r["L_km"] == L and r["W2"] == W and r["policy"] == p][0][k]

P, F, ST = "Proposed", "FCFS (ETSI 014)", "Static split"
L0 = d["L_main"]
G = d["main"][0]["key_rate_bps"]
l3dem = d["main"][0]["l3_demand_bps"]; t2dem = d["main"][0]["t2_demand_bps"]
cP, cF, cS = M(P, "otp_cov_T1"), M(F, "otp_cov_T1"), M(ST, "otp_cov_T1")
vP, vF, vS = M(P, "viol_per_hour"), M(F, "viol_per_hour"), M(ST, "viol_per_hour")
opt = d["offline_main"]["otp_cov_T1"]
p1 = [r for r in d["main"] if r["policy"] == P and r["seed"] == 1][0]["otp_cov_T1"]
ratio_opt = p1 / opt
dF = paired(F, "otp_cov_T1"); dFv = paired(F, "viol_per_hour")
dK = paired("Proposed w/o KBRS", "otp_cov_T1"); dSw = paired("Proposed w/o SLAS", "switches_per_hour")
seq1 = q["seq"][0]; seq40 = [s for s in q["seq"] if s["dist_km"] == 40][0]
qb_lo = min(s["qber"] for s in q["seq"]); qb_hi = max(s["qber"] for s in q["seq"])
mdl = {m["dist_km"]: m["skr_bps"] for m in q["model"]}
def W(L):  # waste
    return [r for r in d["distance"] if r["policy"] == P and r["L_km"] == L][0]["key_waste"]

D = Doc(REFS, spacing=1.5)

# ---------------- front matter ----------------
D.para("**Key-Budget-Aware QKD-Secured Geo-Replication for Distributed Cloud Storage**", align="center", indent=False, size=16)
D.para("[Author One]^{a}, [Author Two]^{a,*}, [Author Three]^{b}", align="center", indent=False)
D.para("^{a} [Department, Institution, City, Postcode, Country]", align="center", indent=False, size=10)
D.para("^{b} [Department, Institution, City, Postcode, Country]", align="center", indent=False, size=10)
D.para("^{*} Corresponding author. E-mail address: [email]", align="center", indent=False, size=10)

D.heading("Highlights", 1)
D.bullets(["QKD key is budgeted against 14 days of real Azure blob replication traffic",
           "A demand forecaster holds a key reserve for commit and regulated records",
           f"One-time-pad coverage of critical records rises from {pct(cF)}% to {pct(cP)}% at {L0:.0f} km",
           f"The online scheduler reaches {pct(ratio_opt)}% of an offline linear-programming bound",
           "Deferring bulk data for key adds lag but almost no one-time-pad coverage"])

D.heading("Abstract", 1)
D.para(f"Geo-replication copies cloud data between distant data centres. Long-lived replicas are exposed to "
       f"harvest-now-decrypt-later attacks. Quantum key distribution (QKD) gives keys whose secrecy rests on physics, "
       f"but its key rate is small next to replication traffic. Standard key delivery serves requests first come, first "
       f"served. This work treats QKD key as a budget. Three methods are proposed. The key-budget-aware replication "
       f"scheduler (KBRS) allocates key by data tier and deadline. The trace-driven key-pool forecaster (TKPF) predicts "
       f"critical demand and holds a key reserve. Security-level adaptive switching (SLAS) changes protection levels "
       f"with hysteresis. The methods were evaluated on the Azure Functions blob access trace "
       f"({tr['rows']/1e6:.1f} million events, 14 days). Key rates came from a decoy-state BB84 model checked against "
       f"SeQUeNCe 1.2.0. At {L0:.0f} km, one-time-pad coverage of commit and regulated records rose from {pct(cF)}% "
       f"under first-come delivery to {pct(cP)}%. Floor-violation seconds fell from {vF:.1f} to {vP:.1f} per hour. "
       f"The online scheduler reached {pct(ratio_opt)}% of an offline linear-programming bound. A static key split "
       f"covered only {pct(cS)}%. Deferring bulk data to wait for key added up to "
       f"{defer(140.0, 60, P, 'lag_T2_mean_s'):.0f} s of mean lag for only "
       f"{100*(defer(140.0, 60, P, 'otp_cov_T2')-defer(140.0, 0, P, 'otp_cov_T2')):.2f} points of coverage. "
       f"One-time pad therefore suits small critical records, not bulk payloads.", indent=False)
D.para("*Keywords:* Cloud storage; Data replication; Key management; Post-quantum security; Quantum key distribution; "
       "Trace-driven simulation", indent=False)

# ---------------- 1. Introduction ----------------
D.heading("1. Introduction", 1)
D.heading("1.1. Motivation", 2)
D.para("Cloud providers copy each write to more than one data centre. This geo-replication protects data against site "
       "failure and keeps reads close to users [@dynamo,@spanner]. Many systems trade latency against consistency and cost "
       "when they place replicas [@spanstore,@caerus]. The replica traffic crosses public or leased fibre. It is encrypted, "
       "but the encryption keys are agreed with public-key methods.")
D.para("Those methods are at risk. A large quantum computer would break RSA and elliptic-curve key exchange [@shor]. "
       "Recent estimates bring the required machine closer than once assumed [@gidney]. An attacker can record ciphertext "
       "today and decrypt it later. Data that must stay secret for decades is exposed now [@mosca]. Stored replicas of health, "
       "legal or financial records fall in this class. Even end-to-end encrypted cloud storage has shown practical weaknesses "
       "[@hofmann].")
D.heading("1.2. QKD and its bottleneck", 2)
D.para("Quantum key distribution (QKD) offers a different basis. Two sites grow a shared secret key from single photons "
       "[@bb84]. Its secrecy follows from physics, not from a hard mathematical problem [@scarani,@xu,@pirandola]. A key used "
       "once as a one-time pad (OTP) gives information-theoretic secrecy [@shannon]. Metro QKD networks have run for years "
       "[@peev,@sasaki,@dynes]. Field trials now secure data-centre interconnects [@qiu24,@wu25lsa].")
D.para("The catch is rate. Laboratory systems now exceed 100 Mbit/s over short spans [@li23,@grunen23]. The rate still falls "
       "by about an order of magnitude every 50 km of fibre [@tf18,@wang22,@liu23]. Replication moves gigabytes. A one-time pad "
       "needs one key bit per data bit. Key is therefore a scarce resource that must be spent with care. Post-quantum "
       "cryptography is the classical alternative [@fips203,@joseph]. It needs no special hardware. Its security still rests "
       "on computational assumptions, and the two approaches suit different use cases [@aquina].")
D.heading("1.3. Research gap", 2)
D.para("Key delivery between a QKD layer and its applications is standardised [@etsi014,@itu3800]. The ETSI GS QKD 014 "
       "interface hands key to whichever application asks first. Surveys of QKD networks list key management as an open "
       "problem [@cao22,@mehic20,@dervisevic,@mehic24]. The closest prior work schedules QKD key for power-grid messages with "
       "priority classes and a reserve [@zhu25]. It uses synthetic traffic. Distributed storage built on QKD and secret "
       "sharing has also been shown [@fujiwara16,@fujiwara22]. None of these studies measures key budgeting against real "
       "replication traffic. None reports how close a practical scheduler comes to the best possible allocation. It is also "
       "unclear whether bulk replica data should wait for OTP key or move at once under AES.")
D.heading("1.4. Contributions", 2)
D.para("This work makes four contributions.", indent=False)
D.bullets(["A formulation of key-budget-aware geo-replication with four security levels, per-tier security floors and a "
           "recovery-point deadline.",
           "Three methods: KBRS for tier-aware key allocation, TKPF for forecast-driven key reserves, and SLAS for "
           "security-level switching with hysteresis, with propositions on their behaviour.",
           "A trace-driven evaluation on 14 days of real Azure storage writes. Key rates come from a decoy-state model "
           "checked in SeQUeNCe. An offline linear-programming bound is computed on the same realisation.",
           "Two findings for practice: key budgeting matters only in a narrow band of link lengths, and deferring bulk data "
           "for OTP key adds lag without a useful security gain."], numbered=True)
D.heading("1.5. Paper organisation", 2)
D.para("Section 2 reviews related work. Section 3 states the system model and the problem. Section 4 presents the three "
       "methods and their properties. Section 5 describes the experimental setup. Section 6 reports the results. Section 7 "
       "discusses limitations, and Section 8 concludes.")

# ---------------- 2. Related work ----------------
D.heading("2. Related Work", 1)
D.heading("2.1. Cloud geo-replication and its security", 2)
D.para("Geo-replicated stores range from eventually consistent key-value systems [@dynamo] to globally consistent "
       "databases [@spanner]. Placement studies trade latency against cost across providers [@spanstore]. Recent transaction "
       "protocols cut commit latency across regions [@caerus]. These systems assume that transport encryption is sound. A "
       "recent study of end-to-end encrypted cloud storage found broken designs in deployed products [@hofmann]. None of "
       "these works considers quantum-safe key supply.")
D.heading("2.2. QKD networks and deployed metro links", 2)
D.para("Large QKD testbeds were built in Vienna [@peev], Tokyo [@sasaki] and Cambridge [@dynes]. Survey work tracks the "
       "move from testbeds to network services [@cao22,@mehic24]. Data-centre interconnect trials now carry encrypted traffic "
       "over QKD-keyed links [@qiu24]. Multi-core fibre can carry QKD next to high-rate data [@wu25lsa]. Detector and "
       "post-processing advances push secret-key rates past 100 Mbit/s at short range [@li23,@grunen23]. Twin-field protocols "
       "extend reach beyond 800 km at very low rate [@tf18,@wang22,@liu23]. The gap between key rate and data rate remains "
       "large for any span longer than a metro link.")
D.heading("2.3. QKD key management and key relay", 2)
D.para("ETSI GS QKD 014 defines a REST interface for key delivery [@etsi014]. ITU-T Y.3800 sets out a layered network "
       "architecture [@itu3800]. Key management surveys catalogue key storage, relay and supply functions [@mehic20,@dervisevic]. "
       "An open, standards-aware key management framework was proposed for scalable networks [@sanz25]. TLS and VPN stacks "
       "have been wired to ETSI key delivery [@prevost25,@paixao26]. Routing and resource allocation schemes assign key across "
       "multi-hop paths [@bi24,@cvitic25]. Other work matches key output length to user requests [@martin26] or predicts "
       "secret-key rates with neural networks [@zhou22]. OTP-protected error correction can also save key during distillation "
       "[@novak]. The scheduler of Zhu [@zhu25] is the nearest to this work. It ranks power-grid messages, keeps an emergency "
       "reserve and falls back from OTP to AES. It is evaluated on synthetic traffic. It does not consider storage tiers, "
       "replication deadlines or an optimality bound.")
D.heading("2.4. Post-quantum cryptography as the classical alternative", 2)
D.para("NIST has standardised ML-KEM, derived from CRYSTALS-Kyber [@fips203,@kyber]. Migration guidance stresses crypto-agility "
       "and early action [@joseph]. ML-KEM adds little latency to TLS 1.3 [@zheng24]. Hybrid designs combine classical and "
       "post-quantum key exchange [@giron], and QKD with post-quantum methods [@garms]. A recent analysis compared deployed QKD "
       "use cases with post-quantum cryptography and found that each suits different threat models [@aquina]. This work uses "
       "ML-KEM as a reference level, not as a competitor to beat.")
D.heading("2.5. Summary of the gap", 2)
D.para("Table 1 compares this work with the closest studies. No prior study combines data-criticality-aware key allocation, "
       "demand forecasting, a stated security floor and a real cloud workload.")
D.table("Comparison of this work with the closest prior studies.",
        [["Study", "QKD key used", "Data-criticality aware", "Demand forecasting", "Security floor stated", "Real workload trace"],
         ["ETSI GS QKD 014 delivery [@etsi014]", "Yes", "No", "No", "No", "No"],
         ["Fujiwara et al. [@fujiwara22]", "Yes", "No", "No", "No", "No"],
         ["Qiu et al. [@qiu24]", "Yes", "No", "No", "No", "Field trial"],
         ["Garms et al. [@garms]", "Yes (hybrid)", "No", "No", "No", "No"],
         ["Zhu [@zhu25]", "Yes", "Yes", "EWMA quotas", "Partial", "No (synthetic)"],
         ["This work", "Yes", "Yes", "Quantile reserve", "Yes", "Yes (Azure, 14 days)"]],
        widths=[4.2, 2.0, 2.5, 2.6, 2.4, 2.6])

# ---------------- 3. System model ----------------
D.heading("3. System Model and Problem Formulation", 1)
D.heading("3.1. Architecture", 2)
D.para("Fig. 1 shows the architecture. A primary data centre replicates each write to a secondary site. A QKD link of "
       "length L joins the two sites. Both ends hold identical key pools, indexed by key identifiers. A key management layer "
       "decides which data receives which protection. The encryption engine applies a one-time pad or AES-256 [@fips197]. "
       "Ciphertext and key identifiers travel on the ordinary classical channel.")
D.figure(f"{FIG}/fig1_architecture.png",
         "System architecture. Writes replayed from the Azure blob trace enter the replication layer. The key management "
         "layer (TKPF, KBRS, SLAS) draws on the QKD key pool and drives the encryption engine. Only ciphertext and key "
         "identifiers cross the classical channel.")
D.heading("3.2. QKD link model", 2)
D.para("Each link runs decoy-state BB84 [@bb84,@hwang,@lo05]. The overall transmittance of a link of length L is")
D.equation("η(L) = 10^{−αL/10} · η_{det}")
D.para("where α is the fibre loss in dB/km and η_{det} is the detector efficiency. With signal intensity μ and background "
       "yield Y_{0}, the gain and error rate of signal states are", indent=False)
D.equation("Q_{μ} = Y_{0} + 1 − e^{−ημ},   E_{μ} = [ Y_{0}/2 + e_{d}(1 − e^{−ημ}) ] / Q_{μ}")
D.para("where e_{d} is the misalignment error. The single-photon yield and error rate follow the infinite-decoy estimates "
       "Y_{1} = Y_{0} + η and e_{1} = (Y_{0}/2 + e_{d}η)/Y_{1}, with Q_{1} = Y_{1}μe^{−μ} [@lo05]. The secret-key rate is", indent=False)
D.equation("R(L) = f_{clk} · q · { Q_{1}[1 − h_{2}(e_{1})] − Q_{μ} f_{EC} h_{2}(E_{μ}) }")
D.para("where f_{clk} is the source clock, q is the sifting factor, f_{EC} is the error-correction efficiency and h_{2} is the "
       "binary entropy. Error correction uses Cascade [@cascade]. The asymptotic bound is used here. Finite-key effects lower "
       "the rate for short blocks [@tomamichel,@lim14]. They are treated as a scale factor in the sensitivity study. Each "
       "second the link adds key g(t) = R(L)(1 + ε_{t}) to the pool, where ε_{t} is Gaussian jitter with a 5% standard "
       "deviation.", indent=False)
D.para("The error model was checked in SeQUeNCe 1.2.0 [@sequence]. That simulator models the laser, the fibre and the "
       "polarisation detectors, and runs BB84 sifting. It has no privacy amplification or decoy module. The final rate "
       "therefore comes from Eq. (3), and SeQUeNCe supplies a check on loss scaling and error rate (Section 5.2).")
D.heading("3.3. Replication demand model", 2)
D.para("Demand comes from the Azure Functions blob access trace [@azure,@faast]. Every write in a primary region must reach "
       "its secondary site. Writes belong to applications. Each application is assigned once to a tier by a fixed hash of its "
       "anonymised name. Tier T1 (regulated) holds 10% of applications. Tier T2 (confidential) holds 20%. Tier T3 (standard) "
       "holds the rest. Each write also produces a 512-bit commit record. The record carries the object tag, a truncated hash "
       "and metadata. Commit records always need the highest protection.")
D.heading("3.4. Security levels", 2)
D.para("Table 2 defines four security levels and their key cost. Level L3 is the one-time pad. It consumes one key bit per "
       "data bit. Level L2 is AES-256 re-keyed from QKD key every second. Level L1 re-keys every 60 s. Level L0 uses ML-KEM "
       "only and consumes no QKD key. Each tier has a floor, which is the lowest level it may use. T1 payloads and all commit "
       "records need L3. T2 needs at least L2 and prefers L3. T3 needs at least L1 and prefers L2.")
D.table("Security levels, key cost and tier requirements.",
        [["Level", "Mechanism", "QKD key cost", "Used by"],
         ["L3", "One-time pad", "1 bit per data bit", "T1 payload, all commit records (floor); T2 (preferred)"],
         ["L2", "AES-256, re-key every 1 s", "256 bit per stream per s", "T2 (floor); T3 (preferred)"],
         ["L1", "AES-256, re-key every 60 s", "256/60 bit per stream per s", "T3 (floor)"],
         ["L0", "ML-KEM only", "None", "Reference only (below every floor)"]],
        widths=[1.3, 4.0, 4.0, 6.6], left_cols=(0, 1, 3))
D.heading("3.5. Problem formulation", 2)
D.para("Time is divided into one-second slots. Let P(t) be the key pool of a link, with capacity B_{max}. Let c(t) be the "
       "key spent in slot t. The pool evolves as")
D.equation("P(t+1) = min{ B_{max},  P(t) + g(t) − c(t) },   0 ≤ c(t) ≤ P(t) + g(t)")
D.para("Spending splits into the mandatory re-key floors f(t), OTP for T1 and commit bits x_{1}(t), OTP upgrades for T2 "
       "x_{2}(t) and the T3 upgrade from L1 to L2 u_{3}(t):", indent=False)
D.equation("c(t) = f(t) + x_{1}(t) + x_{2}(t) + u_{3}(t),   f(t) = 256 [ S_{2}(t)/τ_{min} + S_{3}(t)/τ_{max} ]")
D.para("where S_{2} and S_{3} are the active T2 and T3 streams. A T1 or commit bit that arrives at time a must be covered by "
       "OTP by a + D, where D is the recovery-point deadline. Otherwise it is sent under L2 and counted as a floor violation. "
       "The objective is lexicographic. The first goal is the share of T1 and commit bits protected by OTP:", indent=False)
D.equation("maximise  Σ_{t} x_{1}(t) / Σ_{t} A_{1}(t),   then  Σ_{t} [ x_{2}(t) + w_{3} u_{3}(t) ]")
D.para("where A_{1}(t) counts arriving T1 and commit bits and w_{3} is a small weight. Constraints are the pool dynamics in "
       "Eq. (4), the cost split in Eq. (5), the deadline D and the rule that floors are paid first.", indent=False)
D.heading("3.6. Notation", 2)
D.para("Table 3 lists the notation.")
D.table("Notation.",
        [["Symbol", "Meaning"],
         ["L, α", "Fibre length (km); fibre loss (dB/km)"],
         ["R(L), g(t)", "Secret-key rate (bit/s); key generated in slot t (bit)"],
         ["P(t), B_{max}", "Key pool (bit); pool capacity (bit)"],
         ["A_{1}(t), A_{2}(t)", "Arriving T1 + commit bits and T2 bits in slot t"],
         ["Q_{1}(t)", "T1 + commit bits queued and not yet protected"],
         ["S_{2}(t), S_{3}(t)", "Active T2 and T3 streams"],
         ["τ_{min}, τ_{max}", "AES re-key intervals for L2 and L1 (s)"],
         ["D", "Recovery-point deadline for T1 and commit bits (s)"],
         ["H, q_{F}", "TKPF forecast horizon (s); forecast quantile"],
         ["Rsv(t)", "TKPF key reserve (bit)"],
         ["W_{2}", "Maximum wait of T2 bits for OTP key (s)"]],
        widths=[4.0, 11.9], left_cols=(0, 1))
D.heading("3.7. Assumptions", 2)
D.bullets(["Each primary region replicates to one secondary site over one dedicated QKD link. The ten links have equal length.",
           "Both key pools stay synchronised. Key identifiers travel with the ciphertext.",
           "The classical channel has enough capacity. Only key availability delays replication.",
           "Tier assignment and the 512-bit commit record are modelling choices. Their effect is reported in Section 7.",
           "AES-256 with fresh QKD key is treated as quantum-safe at the security level stated by its key length [@fips197]."])

# ---------------- 4. Methods ----------------
D.heading("4. Proposed Methods", 1)
D.heading("4.1. KBRS: key-budget-aware replication scheduler", 2)
D.para("KBRS runs once per slot and per link. It first pays the re-key floors. It then protects queued T1 and commit bits "
       "in order of their deadlines. All such bits share the same relative deadline D, so the oldest bit is always the most "
       "urgent [@liu73]. KBRS may use the whole pool for this, including the reserve. Upgrades come last. They may spend only "
       "the key above the reserve, and only when SLAS reports the normal mode. A use-or-lose rule spends any key that would "
       "overflow B_{max} on upgrades. Algorithm 1 gives the steps.")
D.algorithm("KBRS, one slot of one link",
            ["**Input:** pool P, generation g, queues Q_{1}, Q_{2}, streams S_{2}, S_{3}, reserve Rsv, mode m",
             "P ← P + g",
             "pay floors f = 256(S_{2}/τ_{min} + S_{3}/τ_{max}); P ← P − min(P, f)",
             "**for** age a = D−1 **down to** 0 **do**   (oldest first)",
             "  x ← min(Q_{1}[a], P); protect x bits with OTP; Q_{1}[a] ← Q_{1}[a] − x; P ← P − x",
             "budget ← (m = normal) ? P − Rsv : 0",
             "budget ← max(budget, P + g − B_{max})   (use-or-lose)",
             "**if** budget ≥ cost of T3 upgrade **then** re-key T3 at τ_{min}; reduce budget",
             "**for** age a = W_{2} **down to** 0 **do** protect min(Q_{2}[a], budget) T2 bits with OTP",
             "send T1 bits of age D−1 under L2 (count violation); send T2 bits older than W_{2} under L2",
             "age all queues by one slot; P ← min(P, B_{max})"])
D.para("Each slot costs O(D) operations per link for the queue scan. With D = 60 and ten links, a slot needs about 600 "
       "operations. The scheduler adds no measurable delay.")
D.heading("4.2. TKPF: trace-driven key-pool forecaster", 2)
D.para("TKPF predicts how much L3 key the next H seconds will need. At the start of each minute it takes the q_{F}-quantile "
       "of per-minute L3 demand over the previous six hours. Only past data are used. The reserve is the forecast shortfall "
       "plus the bits already queued:")
D.equation("Rsv(t) = max{ 0,  (H/60) · Â_{q}(t) − R(L) · H } + Q_{1}(t)")
D.para("where Â_{q}(t) is the rolling quantile of L3 demand per minute. A burst larger than the expected generation over "
       "the horizon raises the reserve. Upgrades then wait. Algorithm 2 gives the steps.", indent=False)
D.algorithm("TKPF, once per minute and link",
            ["**Input:** history of per-minute L3 demand, horizon H, quantile q_{F}, window 360 min",
             "Â_{q} ← q_{F}-quantile of the last 360 minutes (excluding the current minute)",
             "shortfall ← max(0, (H/60)·Â_{q} − R(L)·H)",
             "every slot: Rsv(t) ← shortfall + Q_{1}(t)"])
D.heading("4.3. SLAS: security-level adaptive switching", 2)
D.para("SLAS sets the mode of each link. It enters the degraded mode when the pool falls below the reserve. It returns to "
       "normal only when the pool exceeds the reserve by 30 s of generation:")
D.equation("m(t) ← degraded if P(t) < Rsv(t);   m(t) ← normal if P(t) > Rsv(t) + 30R(L)")
D.para("In the degraded mode, T3 stays at L1 and T2 receives no OTP. The gap between the two thresholds prevents rapid "
       "flapping. Algorithm 3 gives the steps.", indent=False)
D.algorithm("SLAS, every slot and link",
            ["**if** m = normal **and** P < Rsv **then** m ← degraded; count a switch",
             "**else if** m = degraded **and** P > Rsv + 30·R(L) **then** m ← normal; count a switch",
             "**if** m = degraded **then** hold T3 at L1 and stop T2 upgrades"])
D.heading("4.4. Theoretical properties", 2)
D.para("**Proposition 1** (oldest-first is optimal for T1). Consider any policy that spends key only on floors and on T1 "
       "and commit bits. Among such policies, serving the oldest queued bits first minimises the number of bits that miss "
       "the deadline D.")
D.para("*Proof.* All bits share the relative deadline D. Take a schedule that serves a younger bit while an older bit waits. "
       "Swapping the two leaves total key use unchanged. The older bit now leaves earlier. The younger bit has a later "
       "deadline, so it cannot miss where the older one did not. Repeated swaps give the oldest-first schedule without adding "
       "misses. This is the classic exchange argument for earliest-deadline-first [@liu73]. ∎")
D.para("**Proposition 2** (protection on arrival). Let g'(s) = g(s) − f(s) be the key left after floors. Suppose that at time t "
       "the pool satisfies P(t) ≥ Q_{1}(t) and, for every s in (t, t + H],")
D.equation("Σ_{u=t+1}^{s} A_{1}(u) ≤ P(t) − Q_{1}(t) + Σ_{u=t+1}^{s} g'(u)")
D.para("Then KBRS protects every T1 and commit bit that arrives in (t, t + H] in its arrival slot.", indent=False)
D.para("*Proof.* KBRS serves T1 bits before any upgrade. Upgrades never take key below Rsv(t) ≥ Q_{1}(t). By Eq. (9) the "
       "key that reaches the pool up to slot s always covers the queue plus all arrivals so far. No arriving bit ever finds "
       "the pool empty. ∎ TKPF keeps P(t) − Q_{1}(t) ≥ (H/60)Â_{q} − R(L)H whenever an upgrade is made. The condition in "
       "Eq. (9) therefore holds for any arrival curve that stays below the forecast line.")
D.para("**Proposition 3** (offline bound). Aggregate the slots of one realisation into minutes. Let L3 and T2 demand of "
       "minute m be served by key from minute m or m + 1, and cap the pool only at minute boundaries. The linear program that "
       "maximises 1000 x_{1} + x_{2} under these rules gives an upper bound. It bounds the T1 coverage of any online "
       "policy that pays the re-key floors first, on the same realisation.")
D.para("*Proof.* Each constraint of the program is a relaxation of a constraint of the one-second model. The deadline is "
       "looser, the capacity is checked less often and the T3 upgrade is free. Any online schedule is therefore feasible "
       "for the program. ∎ The program is solved with HiGHS [@highs] through SciPy [@scipy].")
D.heading("4.5. Integration", 2)
D.para("Fig. 2 shows the order of operations in each slot. Arrivals and key generation come first. Floors are paid next. "
       "TKPF and SLAS then fix the reserve and the mode. KBRS spends the key, deadlines are applied and the queues age.")
D.figure(f"{FIG}/fig2_workflow.png",
         "Order of operations in each one-second slot. Steps 4 and 5 (TKPF, SLAS) gate the upgrades in step 7. Step 6 "
         "(KBRS) may draw on the reserve for T1 and commit bits.")

# ---------------- 5. Experimental setup ----------------
D.heading("5. Experimental Setup", 1)
D.heading("5.1. Dataset", 2)
regions = d["regions"]
D.para(f"The Azure Functions blob access trace covers 14 days from November to December 2020 [@azure,@faast]. It holds "
       f"{tr['rows']:,} blob accesses from {tr['unique_apps']} applications in {tr['regions']} anonymised regions. "
       f"Of these, {dem['writes_total']:,} are writes. The ten regions with the most T1 and T2 volume were selected. "
       f"Table 4 lists their demand. Demand is very uneven. Region iic carries most of the T1 volume. Region bey carries "
       f"most of the T2 volume, much of it in multi-gigabit objects.")
import polars as pl
sys.path.insert(0, "/home/claude/hema")
from sw1.sim import load, META_BITS
_, A = load(10, None)
secs = A["writes"].shape[1] * 60
rows = [["Region", "Writes", "T1 + commit (kbit/s)", "T2 (kbit/s)", "Peak minute L3 (kbit/s)"]]
for i, r in enumerate(regions):
    l3 = (A["t1_bits"][i] + A["writes"][i] * META_BITS)
    rows.append([r, f"{int(A['writes'][i].sum()):,}", f"{l3.sum()/secs/1e3:.2f}", f"{A['t2_bits'][i].sum()/secs/1e3:.2f}",
                 f"{(l3/60/1e3).max():.1f}"])
rows.append(["All ten", f"{int(A['writes'].sum()):,}", f"{l3dem/1e3:.2f}", f"{t2dem/1e3:.2f}", "–"])
rows_dem = [r[:] for r in rows]
apt = {x["tier"]: x["len"] for x in dem["apps_per_tier"]}
D.table(f"Replication demand of the ten selected regions (14-day means). Applications per tier over the whole trace: "
        f"T1 {apt[1]}, T2 {apt[2]}, T3 {apt[3]}.", rows, widths=[2.2, 2.6, 3.6, 2.8, 4.0])
D.heading("5.2. QKD simulation", 2)
D.para(f"SeQUeNCe 1.2.0 ran BB84 sifting over fibre of 1 to 40 km with 0.2 dB/km loss, a mean photon number of 0.5 and an "
       f"80 MHz source. The sifted rate fell from {seq1['sifted_bps']/1e6:.2f} Mbit/s at 1 km to "
       f"{seq40['sifted_bps']/1e6:.2f} Mbit/s at 40 km. The QBER stayed between {100*qb_lo:.2f}% and {100*qb_hi:.2f}%. "
       f"This sits below the 1% misalignment error used in Eq. (3), so the model is conservative. Fig. 3 shows both. The "
       f"secret-key model assumes a 1 GHz clock, 20% detector efficiency, Y_{{0}} = 10^{{−6}}, μ = 0.5 and f_{{EC}} = 1.16. "
       f"It gives {mdl[100.0]/1e3:.0f} kbit/s at 100 km and {mdl[140.0]/1e3:.1f} kbit/s at 140 km.")
D.figure(f"{FIG}/fig3_keyrate.png",
         "(a) Secret-key rate of the decoy-state model and sifted rate measured in SeQUeNCe, against fibre length. The two "
         "use different source clocks, so only their slopes are comparable. The dashed line marks the main setting. (b) QBER "
         "of the model (misalignment error 1%) and of SeQUeNCe.")
D.heading("5.3. Region-to-link mapping and record classification", 2)
D.para("Each selected region is a primary site with its own link. All links share the length L. The main setting uses "
       f"L = {L0:.0f} km. At this length the key rate ({G/1e3:.1f} kbit/s per link) sits close to the mean L3 demand of the "
       f"busiest region. This is the regime in which allocation choices matter. The same ratio of supply to demand arises "
       "on shorter links with slower field equipment. Section 6.6 varies the key rate directly. Tiers follow the hash rule "
       "of Section 3.3. Arrivals within a minute follow a Poisson process with the minute's write count. Each write carries "
       "its share of the minute's bytes.")
D.heading("5.4. Parameters", 2)
D.para("Table 5 lists the parameters and their sources.")
D.table("Simulation parameters.",
        [["Parameter", "Value", "Source / reason"],
         ["Fibre loss α", "0.2 dB/km", "Standard single-mode fibre"],
         ["Source clock, μ", "1 GHz, 0.5", "High-rate systems [@li23,@grunen23]"],
         ["Detector efficiency, Y_{0}", "20%, 10^{−6}", "Typical InGaAs/SNSPD range [@xu]"],
         ["Misalignment e_{d}, f_{EC}", "1%, 1.16", "Conservative versus SeQUeNCe QBER"],
         ["Key jitter", "5% (Gaussian)", "Assumption"],
         ["Pool capacity B_{max}", "600 s of generation", "Varied 60–3600 s"],
         ["Deadline D", "60 s", "Recovery-point objective"],
         ["τ_{min}, τ_{max}", "1 s, 60 s", "Re-key intervals for L2, L1"],
         ["TKPF horizon H, q_{F}", "120 s, 0.95", "Varied 30–600 s, 0.90–0.99"],
         ["T2 maximum wait W_{2}", "0 s", "Varied 0–60 s"],
         ["Link length L", f"{L0:.0f} km", "Varied 40–200 km"],
         ["Replay length, seeds", "14 days, 3 seeds", "Full trace"]],
        widths=[4.5, 3.8, 7.6], left_cols=(0, 2))
D.heading("5.5. Baselines", 2)
D.bullets(["**FCFS (ETSI 014 style):** key requests are served in arrival order. T1, commit and T2 requests share one queue "
           "[@etsi014].",
           "**Static split:** each tier receives a fixed share of generation, set from its long-run demand.",
           "**AES re-key only:** every stream uses L2. No OTP is used.",
           "**ML-KEM only:** no QKD key is used [@fips203]. This is a reference level.",
           "**Offline optimum:** the linear-programming bound of Proposition 3, solved on the realisation of seed 1."],
          numbered=True)
D.heading("5.6. Metrics", 2)
D.para("The primary metric is OTP coverage of T1 and commit bits:")
D.equation("C_{1} = Σ_{t} x_{1}(t) / Σ_{t} A_{1}(t)")
D.para("The floor-violation rate counts seconds in which at least one T1 or commit bit left under L2, per hour of trace. Key "
       "utilisation is key spent over key generated. Waste is key lost to pool overflow. T2 coverage and the share of T3 "
       "stream-seconds at L2 measure upgrades. Mode switches per hour measure stability. Replication lag is the time a bit "
       "waits for key.", indent=False)
D.heading("5.7. Implementation", 2)
D.para("The simulator is written in Python 3.13.16 with NumPy 2.5.3 and Polars 2.0.0. The slot loop is compiled with Numba "
       "0.68.0 [@numba]. The offline bound uses SciPy 1.18.1 and HiGHS [@scipy,@highs]. Runs used a two-core Intel Xeon at "
       f"2.8 GHz. A 14-day replay of one policy took a few seconds. The full set of {len(d['main']) + len(d['distance']) + len(d['sens']) + len(d['defer'])} "
       f"runs took {d['runtime_s']/60:.0f} min. Seeds 1 to 3 drive arrivals and key jitter. All policies see the same random "
       "stream for a given seed. Appendix A gives the simulator configuration and the steps to reproduce every result. Code and "
       "processed data are available as stated under Data availability.")

# ---------------- 6. Results ----------------
D.heading("6. Results and Discussion", 1)
D.heading("6.1. Main comparison", 2)
D.para(f"Table 6 and Fig. 4 give the results at {L0:.0f} km. KBRS with TKPF and SLAS protected {pct(cP)}% of T1 and commit "
       f"bits with OTP. FCFS reached {pct(cF)}%. The static split reached {pct(cS)}%. Floor-violation seconds fell from "
       f"{vF:.1f} per hour under FCFS to {vP:.1f}. The gain has a price. T2 coverage was {pct(M(P,'otp_cov_T2'))}% against "
       f"{pct(M(F,'otp_cov_T2'))}% for FCFS, because key held in reserve is not spent on T2. Key waste was high for every "
       f"policy ({pct(M(P,'key_waste'))}% for the proposed method). Most of it came from links whose demand was far below "
       f"supply. AES-only and ML-KEM-only runs never met the T1 floor. Their violation rate equals the share of seconds with "
       f"any T1 or commit traffic.")
pols = [P, "Proposed w/o KBRS", "Proposed w/o TKPF", "Proposed w/o SLAS", F, ST, "AES re-key only", "ML-KEM only"]
names = ["Proposed (KBRS+TKPF+SLAS)", "w/o KBRS", "w/o TKPF", "w/o SLAS", "FCFS (ETSI 014)", "Static split", "AES re-key only", "ML-KEM only"]
rows = [["Policy", "T1+commit OTP (%)", "T2 OTP (%)", "T3 at L2 (%)", "Violation s/h", "Key used (%)", "Switches/h"]]
for p, n in zip(pols, names):
    rows.append([n, f"{pct(M(p,'otp_cov_T1'),2)} ± {pct(S(p,'otp_cov_T1'),2)}", f"{pct(M(p,'otp_cov_T2'))}",
                 f"{pct(M(p,'t3_L2_share'))}", f"{M(p,'viol_per_hour'):.2f} ± {S(p,'viol_per_hour'):.2f}",
                 f"{pct(M(p,'key_util'))}", f"{M(p,'switches_per_hour'):.2f}"])
rows.append(["Offline optimum (seed 1)", f"{pct(opt,2)}", f"{pct(d['offline_main']['otp_cov_T2'])}", "–", "–", "–", "–"])
D.table(f"Results at L = {L0:.0f} km over 14 days (mean ± standard deviation over three seeds).", rows,
        widths=[4.2, 3.0, 1.6, 1.6, 2.6, 1.5, 1.6], bold_cells={(1, 1), (1, 4)},
        notes="Violation s/h: seconds per hour in which a T1 or commit bit left below its floor. Key used: share of "
              "generated key that was spent.")
D.figure(f"{FIG}/fig4_main.png",
         f"Main comparison at {L0:.0f} km. (a) OTP coverage of T1 and commit bits; the dashed line is the offline optimum. "
         "(b) Floor-violation seconds per hour. Error bars show the standard deviation over three seeds.")
D.heading("6.2. Demand and supply over time", 2)
D.para("Fig. 5 shows one day of region iic, the region with the most T1 volume. Demand often exceeds the key rate for some "
       "minutes. Under FCFS the pool drains at each burst, because T2 requests take key that T1 bits later need. TKPF keeps "
       "the pool near its reserve, so T1 bits find key when a burst arrives. The static split fills its T1 share early and "
       "then wastes key, while T1 bits time out in other minutes.")
D.figure(f"{FIG}/fig5_timeseries.png",
         "One day (day 5) of region iic at 140 km. (a) T1 and commit demand in 5-minute means against the QKD key rate. "
         "(b) Key-pool level under three policies and the TKPF reserve of the proposed method.")
D.heading("6.3. Effect of link distance", 2)
D.para(f"Fig. 6 sweeps the link length from 40 to 200 km. Up to 100 km, key is plentiful and every policy except the "
       f"static split protects all T1 and commit bits. At 100 km the static split already falls to {pct(dist(ST,100.0))}%. "
       f"The proposed method helps most between 120 and 180 km. At 160 km it covers {pct(dist(P,160.0))}% against "
       f"{pct(dist(F,160.0))}% for FCFS. At 200 km, with {mdl[200.0]:.0f} bit/s of key, no policy can do much. The proposed "
       f"method stays within {100*max(dist('Offline optimum',L)-dist(P,L) for L in (120.0,140.0,160.0,180.0,200.0)):.1f} "
       f"points of the offline optimum at every length. Key budgeting therefore matters in a band of link lengths, not "
       f"everywhere. Table A.1 in Appendix A lists the exact values.")
D.figure(f"{FIG}/fig6_distance.png",
         "Effect of link length (100–200 km; below 100 km all policies except the static split reach 100%). (a) OTP coverage "
         "of T1 and commit bits; the offline optimum (dashed) lies almost on the proposed curve. (b) Floor-violation seconds "
         "per hour, log scale.")
D.heading("6.4. Where the gain comes from", 2)
pr = json.load(open(f"{RES}/sw1_per_region.json"))
iic = [x for x in pr if x["region"] == "iic"][0]; ayi = [x for x in pr if x["region"] == "ayi"][0]
g4 = [x for x in pr if x["region"] == "4gv"][0]
D.para(f"Table 7 splits the {L0:.0f} km results by link. The gain sits almost entirely on region iic. There, mean T1 and "
       f"commit demand ({[r for r in rows_dem if r[0]=='iic'][0][2]} kbit/s) roughly equals the key rate. The proposed method "
       f"covered {pct(iic[P]['cov'])}% of these bits against {pct(iic[F]['cov'])}% for FCFS, and halved the violation rate. "
       f"Region ayi gained a little. On the other links, key was either plentiful or far too short, and all adaptive policies "
       f"behaved the same. Region 4gv shows the second case. Its few T1 objects are larger than the key pool, so no policy "
       f"covered more than {pct(g4[P]['cov'])}%. The static split lost coverage on almost every link, because it reserves key "
       f"for tiers that do not need it at that moment.")
rows = [["Region", "Proposed OTP (%)", "FCFS OTP (%)", "Static OTP (%)", "Proposed viol. s/h", "FCFS viol. s/h", "Key used, proposed (%)"]]
for x in pr:
    rows.append([x["region"], pct(x[P]["cov"], 2), pct(x[F]["cov"], 2), pct(x[ST]["cov"], 2),
                 f"{x[P]['viol']:.2f}", f"{x[F]['viol']:.2f}", pct(x[P]["util"])])
D.table(f"Per-link results at {L0:.0f} km (means over three seeds). OTP: coverage of T1 and commit bits.", rows,
        widths=[1.8, 2.6, 2.3, 2.3, 2.6, 2.3, 2.5])
D.heading("6.5. Ablation study", 2)
D.para(f"Table 8 removes one component at a time. TKPF carries most of the gain. Without it, coverage drops by "
       f"{100*(cP-M('Proposed w/o TKPF','otp_cov_T1')):.2f} points and violations nearly double. KBRS adds "
       f"{100*dK[0]:.2f} points (95% CI {100*dK[1]:.2f} to {100*dK[2]:.2f}). The small size is expected. With a reserve in "
       f"place, T2 rarely competes with T1, so the order of service matters little. SLAS leaves coverage unchanged. Its role "
       f"is stability. It cuts mode switches by {-dSw[0]:.1f} per hour (95% CI {-dSw[2]:.1f} to {-dSw[1]:.1f}).")
rows = [["Variant", "T1+commit OTP (%)", "Δ vs proposed (points)", "Violation s/h", "Switches/h"]]
for p, n in zip(pols[:4], ["Proposed", "w/o KBRS (joint FIFO)", "w/o TKPF (no reserve)", "w/o SLAS (no hysteresis)"]):
    rows.append([n, f"{pct(M(p,'otp_cov_T1'),2)}", "–" if p == P else f"{100*(M(p,'otp_cov_T1')-cP):+.2f}",
                 f"{M(p,'viol_per_hour'):.2f}", f"{M(p,'switches_per_hour'):.2f}"])
D.table(f"Ablation at {L0:.0f} km (means over three seeds).", rows, widths=[5.2, 3.0, 3.4, 2.4, 2.2])
D.heading("6.6. Sensitivity", 2)
D.para(f"Fig. 7 varies three factors. A larger key pool helps every policy, because it stores key across bursts. With "
       f"3600 s of storage the proposed method reached {pct(sens('Bmax_s',3600.0,P))}% against "
       f"{pct(sens('Bmax_s',3600.0,F))}% for FCFS. With only 60 s of storage the two were close "
       f"({pct(sens('Bmax_s',60.0,P))}% and {pct(sens('Bmax_s',60.0,F))}%), since a small pool leaves little to reserve. "
       f"The forecast horizon trades coverage against stability. Moving H from 30 s to 120 s raised coverage from "
       f"{pct(sens('H',30.0,P))}% to {pct(sens('H',120.0,P))}% and cut switches from {sens('H',30.0,P,'switches_per_hour'):.1f} "
       f"to {sens('H',120.0,P,'switches_per_hour'):.1f} per hour. Longer horizons changed little. The forecast quantile had "
       f"almost no effect ({pct(sens('quantile',0.9,P),2)}% at 0.90, {pct(sens('quantile',0.99,P),2)}% at 0.99). Halving the "
       f"key rate cut coverage to {pct(sens('key_scale',0.5,P))}%. Doubling it raised coverage to "
       f"{pct(sens('key_scale',2.0,P))}%. The ranking of policies held in every case.")
D.figure(f"{FIG}/fig7_sensitivity.png",
         f"Sensitivity at {L0:.0f} km. (a) Key-pool capacity in seconds of generation. (b) TKPF horizon: coverage and mode "
         "switches. (c) Key-rate scale factor, a proxy for finite-key losses or slower field equipment.")
D.heading("6.7. Replication lag and the value of deferral", 2)
lag = {p: np.array([r for r in d['main'] if r['policy'] == p and r['seed'] == 1][0]['lag1_hist']) for p in (P, F, ST)}
z = {p: lag[p][0] / lag[p].sum() for p in lag}
D.para(f"Fig. 8(a) shows how long T1 and commit bits waited for key. Under the proposed method, {pct(z[P])}% of these bits "
       f"were protected in their arrival second. Under FCFS the share was {pct(z[F])}%, and under the static split "
       f"{pct(z[ST])}%. Bits that waited the full 60 s left under L2. Fig. 8(b) tests deferral of T2 data. Letting T2 wait up "
       f"to 60 s for OTP key raised T2 coverage at {L0:.0f} km from {pct(defer(140.0,0,P,'otp_cov_T2'),2)}% to "
       f"{pct(defer(140.0,60,P,'otp_cov_T2'),2)}%. It added {defer(140.0,60,P,'lag_T2_mean_s'):.1f} s of mean lag. At 60 km, "
       f"where most key goes unused, the gain was still only {100*(defer(60.0,60,P,'otp_cov_T2')-defer(60.0,0,P,'otp_cov_T2')):.2f} "
       f"points. The cause is object size. T2 volume is dominated by large objects that no realistic key budget covers within a "
       f"minute. Deferral also hurt FCFS, whose T1 coverage fell from {pct(defer(140.0,0,F,'otp_cov_T1'))}% to "
       f"{pct(defer(140.0,60,F,'otp_cov_T1'))}% as T2 requests piled up. Bulk data should therefore move at once under AES. "
       f"OTP should be kept for small, critical records.")
D.figure(f"{FIG}/fig8_lag_defer.png",
         f"(a) Cumulative share of T1 and commit bits against their wait for OTP key at {L0:.0f} km (seed 1). (b) T2 OTP "
         "coverage against mean added replication lag as the maximum T2 wait W_{2} grows from 0 to 60 s, at three link lengths.")
D.heading("6.8. Gap to the offline optimum", 2)
D.para(f"On the seed-1 realisation at {L0:.0f} km, the offline program reached {pct(opt,2)}% and the proposed method "
       f"{pct(p1,2)}%. The online method thus achieved {pct(ratio_opt)}% of the bound. The bound is loose by design, since it "
       "relaxes the deadline and the pool limit. The true gap to the best online policy is therefore no larger than this.")
D.heading("6.9. Statistical significance", 2)
D.para(f"Each policy ran with three seeds on the full 14-day trace. Paired differences against FCFS used the same seed for "
       f"both policies. The coverage gain was {100*dF[0]:.2f} points (95% CI {100*dF[1]:.2f} to {100*dF[2]:.2f}). The change "
       f"in violation rate was {dFv[0]:.2f} s/h (95% CI {dFv[1]:.2f} to {dFv[2]:.2f}). Both intervals exclude zero. Seed "
       "variance was small because 14 days of data average out arrival noise. Three seeds are few. The intervals use the "
       "t-distribution with two degrees of freedom and are wide for that reason.")
D.heading("6.10. Discussion", 2)
D.para("Three lessons follow. First, key budgeting matters only when supply and critical demand are of the same order. On "
       "short metro links, QKD supplies far more key than critical records need, and any reasonable policy works. On very "
       "long links, no policy can help. Operators should size links and pools for this middle band. Second, the gain comes "
       "from reserving key for predictable critical demand, not from clever ordering. A simple quantile forecast was enough. "
       "Third, one-time pad is a poor fit for bulk replica data. Real objects are too large. A practical design protects "
       "commit records and regulated data with OTP, re-keys AES often for the rest, and moves data without waiting.")
D.para("ML-KEM needs no QKD key and protects all tiers at a computational level [@fips203,@aquina]. The question for an "
       "operator is which data justify information-theoretic protection. The framework here answers how much of that data a "
       "given link can cover, and how to spend its key.")

# ---------------- 7. Limitations ----------------
D.heading("7. Limitations and Threats to Validity", 1)
D.bullets(["Key rates come from a simulation model with published parameters, not from a live QKD network. SeQUeNCe checked "
           "loss scaling and error rate. It does not model privacy amplification, so finite-key effects enter only through "
           "the scale factor in Fig. 7(c).",
           "The region-to-link mapping, the tier hash and the 512-bit commit record are modelling assumptions. A different "
           "tier mix changes absolute numbers. The ranking of policies held across every setting tested.",
           "All ten links have the same length. Real deployments mix lengths. Links beyond about 100 km need trusted relays, "
           "which add their own key demand and trust assumptions.",
           "The trace comes from one provider and covers 14 days. Other workloads may have different burst patterns.",
           "Key waste stays high because each link is fixed to one region. Pooling key across links or relaying it would "
           "change this but needs a network model not studied here."])

# ---------------- 8. Conclusion ----------------
D.heading("8. Conclusion and Future Work", 1)
D.para(f"This work treated QKD key as a budget for geo-replication. KBRS, TKPF and SLAS were tested against 14 days of real "
       f"Azure storage writes. At {L0:.0f} km the methods raised OTP coverage of critical records from {pct(cF)}% to "
       f"{pct(cP)}% and cut floor violations from {vF:.1f} to {vP:.1f} seconds per hour. They reached {pct(ratio_opt)}% of an "
       f"offline bound. The forecast-driven reserve gave most of the gain. Deferring bulk data for OTP key did not pay off. "
       "Future work will study entanglement-based QKD with untrusted relays, key pooling across links, traces from more "
       "providers and a testbed deployment.")

# ---------------- declarations ----------------
D.heading("CRediT authorship contribution statement", 1)
D.para("[Author One]: Conceptualization, Methodology, Software, Formal analysis, Writing – original draft. [Author Two]: "
       "Supervision, Validation, Writing – review & editing. [Author Three]: Investigation, Visualization. [Edit to match "
       "actual contributions.]", indent=False)
D.heading("Declaration of competing interest", 1)
D.para("The authors declare that they have no known competing financial interests or personal relationships that could have "
       "appeared to influence the work reported in this paper.", indent=False)
D.heading("Funding", 1)
D.para("This research did not receive any specific grant from funding agencies in the public, commercial, or not-for-profit "
       "sectors. [Edit if funded.]", indent=False)
D.heading("Data availability", 1)
D.para("The Azure Functions blob access trace is public [@azure]. Simulation code, processed demand files and result files "
       "will be made available in a public repository on acceptance. [Insert repository link.]", indent=False)
D.heading("Declaration of generative AI and AI-assisted technologies in the writing process", 1)
D.para("During the preparation of this work the authors used [name of tool] in order to [purpose]. After using this "
       "tool, the authors reviewed and edited the content as needed and take full responsibility for the content of the "
       "publication. [Complete as required by the journal.]", indent=False)


# ---------------- Appendix A ----------------
D.heading("Appendix A. Reproducibility details", 1)
D.heading("A.1. Distance sweep values", 2)
D.para("Table A.1 lists the values behind Fig. 6, for seed 1. The offline optimum is computed on the same realisation as "
       "the proposed method.")
rows = [["L (km)", "Key rate (kbit/s)", "Proposed (%)", "w/o TKPF (%)", "FCFS (%)", "Static (%)", "Offline opt. (%)", "Proposed viol. s/h"]]
for L in (40.0, 60.0, 80.0, 100.0, 120.0, 140.0, 160.0, 180.0, 200.0):
    rows.append([f"{L:.0f}", f"{[r for r in d['distance'] if r['policy']==P and r['L_km']==L][0]['key_rate_bps']/1e3:.2f}",
                 pct(dist(P, L), 2), pct(dist("Proposed w/o TKPF", L), 2), pct(dist(F, L), 2), pct(dist(ST, L), 2),
                 pct(dist("Offline optimum", L), 2), f"{dist(P, L, 'viol_per_hour'):.2f}"])
D.table("OTP coverage of T1 and commit bits against link length (14 days, seed 1).", rows,
        widths=[1.4, 2.2, 2.0, 2.0, 1.8, 1.8, 2.2, 2.5], label="A.1")
D.heading("A.2. SeQUeNCe configuration", 2)
D.para("Table A.2 lists the SeQUeNCe 1.2.0 setup used for the link check. SeQUeNCe expects fibre attenuation in dB per "
       "metre. A value of 0.2 dB/km must therefore be entered as 2 × 10^{−4}. An earlier run of this study used a "
       "natural-log value by mistake. That run gave rates that barely fell with distance and was discarded. The check is "
       "worth repeating in any study that uses this simulator.")
D.table("SeQUeNCe 1.2.0 configuration for the BB84 link check.",
        [["Item", "Setting"],
         ["Nodes", "Two QKDNode instances, BB84 layer only, polarisation encoding"],
         ["Quantum channels", "One in each direction, attenuation 2 × 10^{−4} dB/m, polarisation fidelity 0.99"],
         ["Classical channels", "One in each direction, same length as the fibre"],
         ["Light source", "80 MHz, mean photon number 0.5"],
         ["Run", "20 ms of simulated time per length, key length 256 bit, seed 11"],
         ["Lengths", "1, 5, 10, 20, 30, 40 km"]],
        widths=[3.5, 12.4], left_cols=(0, 1), label="A.2")
D.heading("A.3. Steps to reproduce", 2)
D.bullets(["Download the Azure Functions blob access trace 2020 [@azure] and decompress it.",
           "Run the demand extraction to build per-region, per-minute tier demand and stream counts.",
           "Run the SeQUeNCe link check and the decoy-state model to produce the key-rate table.",
           "Run the trace replay for all policies, seeds, lengths and sensitivity settings. The offline bound is solved "
           "inside the same script for seed 1.",
           "Run the figure and manuscript scripts. Every number in the text is read from the result files, not typed by hand."],
          numbered=True)

n_refs = D.references()
out = "/home/claude/hema/sw1/paper/SW1_QKD_KeyBudget_GeoReplication.docx"
D.save(out)
json.dump({"refs_cited": D.order, "n_refs": n_refs, "figs": D.fig_n, "tables": D.tab_n, "eqs": D.eq_n},
          open("/home/claude/hema/sw1/paper/build_info.json", "w"), indent=1)
print("saved", out, "refs", n_refs, "figs", D.fig_n, "tables", D.tab_n, "eqs", D.eq_n)
