# ===================== Manuscript body, version 2 =====================
# Rules applied: every reference cited exactly once (ascending numbering
# everywhere); every equation, figure and table referred to in the text;
# two orienting sentences after every heading.
EQ = {}
def eq(key, s):
    EQ[key] = D.equation(s)
    return EQ[key]

D.para("*Keywords:* Cloud storage; Data replication; Key management; Post-quantum security; Quantum key distribution; "
       "Trace-driven simulation", indent=False)

# ============ 1. Introduction (~800 words) ============
D.heading("1. Introduction", 1)
D.para("This section explains why replica traffic needs quantum-safe keys and why the key supply is the hard part. It then "
       "states the research gap, the contributions and the layout of the paper.")
D.para("Cloud providers copy every write to more than one data centre. This geo-replication keeps data available when a "
       "site fails and keeps reads close to users. Large production systems depend on it, from highly available key-value "
       "stores [@dynamo] to globally consistent databases [@spanner]. The replica traffic crosses leased or public fibre "
       "between sites. It is encrypted, but the session keys are usually agreed with public-key methods.")
D.para("Those methods face a long-term threat. A large quantum computer would break RSA and elliptic-curve key exchange "
       "in polynomial time [@shor]. Resource estimates for such a machine have fallen sharply in recent years [@gidney]. "
       "An attacker can record ciphertext today and decrypt it once the machine exists. Data that must stay secret for "
       "decades is therefore exposed now [@mosca]. Organisations are advised to start migration early and to keep their "
       "cryptography agile [@joseph]. Replicas of health, legal and financial records fall in this long-lived class. Even "
       "end-to-end encrypted cloud storage products have shown practical design flaws [@hofmann], so the transport layer "
       "deserves fresh attention.")
D.para("Quantum key distribution (QKD) offers a different basis for key agreement. Two sites grow a shared secret from "
       "single photons sent over fibre [@bb84]. Any eavesdropper disturbs the photons and raises the error rate, so the "
       "secrecy rests on physics rather than on a hard mathematical problem [@pirandola]. Security proofs now cover the "
       "imperfections of real devices [@xu]. Metro QKD networks have operated for more than a decade in Vienna [@peev], "
       "Tokyo [@sasaki] and Cambridge [@dynes]. A key used once as a one-time pad (OTP) gives information-theoretic "
       "secrecy. Shorter keys can refresh a symmetric cipher such as AES-256 at a chosen rate.")
D.para("The difficulty is rate. Laboratory systems now exceed 100 Mbit/s of secret key over short spans [@li23,@grunen23]. "
       "The rate still falls by about an order of magnitude for every 50 km of fibre. Twin-field protocols reach beyond "
       "1000 km, but only at very low rates [@tf18,@liu23]. Replication, by contrast, moves gigabytes per hour, and an OTP "
       "needs one key bit for every data bit. Key is therefore a scarce resource that must be spent with care. "
       "Post-quantum cryptography is the classical alternative. NIST has standardised the ML-KEM key-encapsulation "
       "mechanism [@fips203]. It needs no special hardware, but its security still rests on computational assumptions. A "
       "recent analysis of deployed QKD use cases concluded that the two approaches suit different threat models [@aquina].")
D.para("Key delivery between a QKD layer and its applications is standardised. The ETSI GS QKD 014 interface hands key "
       "to whichever application asks first [@etsi014]. The ITU-T Y.3800 recommendation places key management in a "
       "separate network layer [@itu3800]. Surveys of QKD networks list key supply and key scheduling as open problems "
       "[@cao22]. Several gaps follow for cloud replication. No study has measured key budgeting against real replication "
       "traffic. No study reports how close a practical scheduler comes to the best possible allocation. It is also unclear "
       "whether bulk replica data should wait for OTP key or move at once under AES. Section 2 shows that the closest prior "
       "scheduler targets power-grid messages and uses synthetic traffic.")
D.para("This work treats the QKD key pool of each inter-site link as a budget. Writes are grouped into tiers of different "
       "sensitivity. Each tier has a security floor, and commit records must always use OTP. The study makes four "
       "contributions.", indent=True)
D.bullets(["A formulation of key-budget-aware geo-replication with four security levels, per-tier security floors, a "
           "recovery-point deadline and a conservation bound on achievable OTP coverage.",
           "Three methods with proofs: KBRS for tier-aware key allocation, TKPF for forecast-driven key reserves and SLAS "
           "for security-level switching with hysteresis.",
           "A trace-driven evaluation on 14 days of real Azure storage writes. Key rates come from a decoy-state model checked "
           "in a quantum-network simulator. An offline linear-programming bound is computed on the same realisation.",
           "Two findings for practice: key budgeting matters only in a narrow band of link lengths, and deferring bulk data "
           "for OTP key adds lag without a useful security gain."], numbered=True)
D.para("The rest of the paper is organised as follows. Section 2 reviews related work. Section 3 states the system model and "
       "the problem. Section 4 presents the three methods and their properties. Section 5 describes the experimental setup "
       "and Section 6 reports the results. Section 7 discusses limitations, and Section 8 concludes.")

# ============ 2. Related Work ============
D.heading("2. Related Work", 1)
D.para("This section reviews four bodies of work that meet in this paper. For each study it names the authors, the method "
       "and the limitation that matters for key budgeting in cloud replication.")
D.heading("2.1. Cloud geo-replication and its security", 2)
D.para("Geo-replication research has focused on latency, cost and consistency. Security of the replica channel is usually "
       "assumed rather than studied.")
D.para("Wu et al. [@spanstore] built SPANStore, which places replicas across several cloud providers to minimise cost under "
       "latency targets. Its limitation here is that transport security is treated as a given. Hildred et al. [@caerus] "
       "proposed Caerus, a transaction protocol that lowers commit latency for geo-replicated systems. It does not consider "
       "how replica traffic is keyed. Fujiwara et al. [@fujiwara16] combined a QKD network with password-authenticated "
       "secret sharing to build distributed storage that resists computational attacks. Fujiwara et al. [@fujiwara22] later "
       "added third-party verification for long-term secure storage. Both designs secure stored shares. Neither studies how "
       "a limited key rate should be shared among streams of different value, and neither is tested against a production "
       "workload.")
D.heading("2.2. QKD networks and deployed links", 2)
D.para("QKD has moved from laboratory links to field networks and data-centre trials. The work below shows both the reach "
       "of the technology and the rate gap that remains.")
D.para("Wang et al. [@wang22] demonstrated twin-field QKD over 830 km of fibre. The achieved key rates are far below those "
       "needed for data replication. Qiu et al. [@qiu24] built a quantum-secured data-centre interconnect in a field "
       "environment and encrypted live traffic with QKD keys. Their trial covers one link and uses no policy for dividing "
       "key among data classes. Wu et al. [@wu25lsa] carried QKD next to high-throughput classical channels in field-deployed "
       "multi-core fibre. Their work addresses physical-layer coexistence, not key allocation. Mehic et al. [@mehic24] "
       "surveyed quantum cryptography for 5G networks and mapped integration points for QKD. As a survey, it gives no "
       "quantitative study of key scheduling.")
D.heading("2.3. QKD key management, routing and key supply", 2)
D.para("Key management sits between the QKD layer and the applications. Recent work covers architecture, interfaces, "
       "routing and rate prediction.")
D.para("Mehic et al. [@mehic20] described QKD from a networking perspective and listed key storage and relay as core "
       "functions. Dervisevic et al. [@dervisevic] surveyed QKD key management and identified efficient key supply as an "
       "open problem. Both are surveys without workload studies. Sanz et al. [@sanz25] proposed an open, standards-aware key "
       "management framework for scalable networks. Its focus is architecture and interoperability rather than allocation "
       "among data classes. Prévost et al. [@prevost25] implemented TLS on top of ETSI-compliant key delivery, and Paixão et "
       "al. [@paixao26] carried real-time VPN traffic over ETSI GS QKD 014. Both show that applications can consume QKD key. "
       "Prioritising data of different value lies outside their scope. Bi et al. [@bi24] optimised QKD resource allocation "
       "and routing across a network, and Cvitic et al. [@cvitic25] reviewed routing approaches for QKD networks. These "
       "studies work at the network level, not at the level of application tiers. Martin-Megino et al. [@martin26] matched "
       "QKD output to user-defined key-length requirements in non-ideal conditions. Zhou et al. [@zhou22] trained neural "
       "networks to predict secret-key rates for given link parameters. They forecast supply, not demand. Novak [@novak] "
       "analysed OTP-protected error correction and its key savings inside the distillation stage. Zhu [@zhu25] is the "
       "nearest work. The scheduler ranks power-grid messages, keeps an emergency reserve and falls back from OTP to AES. It "
       "is evaluated on synthetic traffic and gives no optimality bound.")
D.heading("2.4. Post-quantum cryptography as the classical alternative", 2)
D.para("Post-quantum cryptography protects data without new hardware. It is the natural reference point for any QKD-based "
       "design.")
D.para("Bos et al. [@kyber] introduced CRYSTALS-Kyber, the basis of ML-KEM. Its security depends on lattice problems that "
       "are believed hard, not on physics. Zheng et al. [@zheng24] showed a faster ML-KEM implementation for TLS 1.3 with "
       "small handshake overhead. That work measures connection set-up, not long-term secrecy of stored replicas. Giron et "
       "al. [@giron] mapped hybrid key-exchange designs that combine classical and post-quantum methods. Garms et al. "
       "[@garms] integrated QKD and post-quantum cryptography in an experimental hybrid cryptosystem. Neither study "
       "addresses how to ration QKD key under bursty application demand.")
D.heading("2.5. Summary of the gap", 2)
D.para("The reviewed work leaves one question open. No study allocates scarce QKD key by data criticality against a real "
       "cloud workload with a stated security floor.")
D.para("Table 1 compares this work with the closest studies on five features. The proposed design is the only one that "
       "combines criticality-aware allocation, demand forecasting, a security floor and a real workload trace.")
D.table("Comparison of this work with the closest prior studies.",
        [["Study", "QKD key used", "Data-criticality aware", "Demand forecasting", "Security floor stated", "Real workload trace"],
         ["ETSI GS QKD 014 (2019)", "Yes", "No", "No", "No", "No"],
         ["Fujiwara et al. (2022)", "Yes", "No", "No", "No", "No"],
         ["Qiu et al. (2024)", "Yes", "No", "No", "No", "Field trial"],
         ["Garms et al. (2024)", "Yes (hybrid)", "No", "No", "No", "No"],
         ["Zhu (2025)", "Yes", "Yes", "EWMA quotas", "Partial", "No (synthetic)"],
         ["This work", "Yes", "Yes", "Quantile reserve", "Yes", "Yes (Azure, 14 days)"]],
        widths=[4.2, 2.0, 2.5, 2.6, 2.4, 2.6])

# ============ 3. System Model ============
D.heading("3. System Model and Problem Formulation", 1)
D.para("This section models the QKD link, the replication demand and the security levels. It then states the allocation "
       "problem and a bound that no policy can beat.")
D.heading("3.1. Architecture", 2)
D.para("The system joins two data centres with a QKD link and a classical channel. The key management layer decides which "
       "data receives which protection.")
D.para("Fig. 1 shows the architecture. A primary data centre replicates each write to a secondary site. A QKD link of "
       "length L joins the two sites, and both ends hold identical key pools indexed by key identifiers. The encryption "
       "engine applies either a one-time pad or AES-256. Ciphertext and key identifiers travel on the ordinary classical "
       "channel, which is assumed to have ample capacity.")
D.figure(f"{FIG}/fig1_architecture.png",
         "System architecture. Writes replayed from the Azure blob trace enter the replication layer. The key management "
         "layer (TKPF, KBRS, SLAS) draws on the QKD key pool and drives the encryption engine. Only ciphertext and key "
         "identifiers cross the classical channel.")
D.heading("3.2. QKD link model", 2)
D.para("Each link runs BB84 with weak coherent pulses and decoy states. The model below gives the secret-key rate as a "
       "function of fibre length.")
D.para("A laser pulse of mean photon number μ holds n photons with the Poisson probability in Eq. (1). Pulses with two or "
       "more photons leak information to a photon-number-splitting attack. Decoy states of different intensity let the "
       "receiver estimate how many detections came from single photons [@hwang].")
eq("pn", "P_{n}(μ) = e^{−μ} μ^{n} / n!")
D.para("The overall transmittance of the link combines fibre loss and detector efficiency, as in Eq. (2). Here α is the fibre "
       "loss in dB/km and η_{det} is the detection efficiency.", indent=False)
eq("eta", "η(L) = 10^{−αL/10} · η_{det}")
D.para("An n-photon pulse is detected if at least one photon arrives or a background count occurs. Eq. (3) gives this yield, "
       "with Y_{0} the background yield per pulse.", indent=False)
eq("yn", "Y_{n} = Y_{0} + 1 − (1 − η)^{n}")
D.para("Summing Eq. (3) over the Poisson distribution of Eq. (1) gives the overall gain of signal pulses in Eq. (4). The "
       "error rate of signal pulses follows in Eq. (5), where e_{d} is the probability that a photon hits the wrong detector "
       "[@lo05].", indent=False)
eq("qmu", "Q_{μ} = Σ_{n≥0} Y_{n} P_{n}(μ) = Y_{0} + 1 − e^{−ημ}")
eq("emu", "E_{μ} = [ Y_{0}/2 + e_{d} (1 − e^{−ημ}) ] / Q_{μ}")
D.para("With an infinite set of decoy intensities the single-photon terms can be recovered exactly. Eq. (6) gives the "
       "single-photon gain and error rate.", indent=False)
eq("q1", "Q_{1} = (Y_{0} + η) μ e^{−μ},   e_{1} = (Y_{0}/2 + e_{d} η) / (Y_{0} + η)")
D.para("Privacy amplification removes the information an eavesdropper may hold. Its cost is measured with the binary "
       "entropy of Eq. (7).", indent=False)
eq("h2", "h_{2}(x) = −x log_{2} x − (1 − x) log_{2}(1 − x)")
D.para("The asymptotic secret-key rate is then given by Eq. (8) [@scarani]. The first term is the key that single photons "
       "can supply after privacy amplification. The second term is the information revealed during error correction. Here "
       "f_{clk} is the source clock, q is the sifting factor and f_{EC} is the efficiency of the error-correction code. Error "
       "correction uses Cascade [@cascade].", indent=False)
eq("rate", "R(L) = f_{clk} · q · { Q_{1} [1 − h_{2}(e_{1})] − f_{EC} Q_{μ} h_{2}(E_{μ}) }")
D.para("Eq. (8) is an asymptotic bound. Finite blocks cost extra key for parameter estimation [@tomamichel], and practical "
       "decoy protocols use only two or three intensities [@lim14]. Both effects lower the rate. Section 6.6 therefore "
       "scales the rate by a factor between 0.5 and 2. In each one-second slot the link adds the key in Eq. (9) to the "
       "pool, where ε_{t} is Gaussian jitter with a standard deviation of 5%.", indent=False)
eq("gt", "g(t) = R(L) · max{0, 1 + ε_{t}},   ε_{t} ~ N(0, 0.05^{2})")
D.heading("3.3. Replication demand model", 2)
D.para("Demand is taken from a real storage trace, not drawn from a synthetic model. Each write must reach its secondary "
       "site and carries a commit record.")
D.para("Each application a is assigned to a tier once, by a fixed hash h(a) of its anonymised name, as in Eq. (10). Tier T1 "
       "(regulated) holds 10% of applications, T2 (confidential) 20% and T3 (standard) the rest.")
eq("tier", "tier(a) = T1 if h(a) mod 100 < 10;  T2 if 10 ≤ h(a) mod 100 < 30;  T3 otherwise")
D.para("The trace gives the write count W(m) and the bytes per tier B_{k}(m) for every minute m. Within a minute, the "
       "number of writes in second t follows the Poisson law in Eq. (11).", indent=False)
eq("kt", "K(t) ~ Poisson( W(m)/60 ),   t ∈ minute m")
D.para("Each write carries its share of the minute's bytes and a 512-bit commit record. The record holds the object tag, a "
       "truncated hash and metadata. Eq. (12) gives the bits that need OTP, A_{1}(t), and the T2 bits, A_{2}(t).",
       indent=False)
eq("a1", "A_{1}(t) = [K(t)/W(m)] · B_{1}(m) + 512 K(t),   A_{2}(t) = [K(t)/W(m)] · B_{2}(m)")
D.heading("3.4. Security levels", 2)
D.para("Four security levels differ in strength and in key cost. Each tier has a floor below which its data must never go.")
D.para("Level L3 is the one-time pad. Shannon showed that a uniformly random key, used once and at least as long as the "
       "message, gives perfect secrecy [@shannon]. Eq. (13) states this property: the ciphertext C reveals nothing about the "
       "message M.")
eq("otp", "Pr[ M = m | C = c ] = Pr[ M = m ]   for all m, c,   provided |K| ≥ |M|")
D.para("Eq. (13) is the reason L3 costs one key bit per data bit. Levels L2 and L1 use AES-256 [@fips197] with a fresh "
       "256-bit QKD key every τ seconds per stream. Eq. (14) gives their key cost per stream per second, κ, and the data "
       "volume V protected by a single key when a stream runs at r_{s} bit/s.", indent=False)
eq("aes", "κ(τ) = 256/τ,   V(τ) = r_{s} · τ")
D.para("A short τ limits the data exposed if one AES key is ever compromised. Level L2 uses τ_{min} = 1 s and L1 uses "
       "τ_{max} = 60 s. Level L0 uses ML-KEM only and spends no QKD key. Table 2 lists the levels, their cost and the tiers "
       "that use them. T1 payloads and all commit records need L3. T2 needs at least L2 and prefers L3. T3 needs at least "
       "L1 and prefers L2.", indent=False)
D.table("Security levels, key cost and tier requirements.",
        [["Level", "Mechanism", "QKD key cost", "Used by"],
         ["L3", "One-time pad", "1 bit per data bit", "T1 payload, all commit records (floor); T2 (preferred)"],
         ["L2", "AES-256, re-key every 1 s", "256 bit per stream per s", "T2 (floor); T3 (preferred)"],
         ["L1", "AES-256, re-key every 60 s", "256/60 bit per stream per s", "T3 (floor)"],
         ["L0", "ML-KEM only", "None", "Reference only (below every floor)"]],
        widths=[1.3, 4.0, 4.0, 6.6], left_cols=(0, 1, 3))
D.heading("3.5. Problem formulation", 2)
D.para("The scheduler decides, every second, how to spend the key in the pool. The decision must respect pool dynamics, "
       "security floors and a deadline.")
D.para("Let P(t) be the key pool of a link with capacity B_{max}, and c(t) the key spent in slot t. The pool evolves as in "
       "Eq. (15). Key that would exceed B_{max} is lost.")
eq("pool", "P(t+1) = min{ B_{max},  P(t) + g(t) − c(t) },   0 ≤ c(t) ≤ P(t) + g(t)")
D.para("Spending splits into four parts in Eq. (16). The term f(t) is the mandatory re-key cost of the floors, x_{1}(t) is "
       "OTP for T1 and commit bits, x_{2}(t) is OTP for T2 and u_{3}(t) is the upgrade of T3 from L1 to L2. S_{2}(t) and "
       "S_{3}(t) are the active T2 and T3 streams.", indent=False)
eq("cost", "c(t) = f(t) + x_{1}(t) + x_{2}(t) + u_{3}(t),   f(t) = 256 [ S_{2}(t)/τ_{min} + S_{3}(t)/τ_{max} ]")
D.para("T1 and commit bits wait in a queue indexed by age a. Eq. (17) shows how the queue ages. New arrivals enter at age 0, "
       "and bits protected in a slot leave the queue.", indent=False)
eq("queue", "Q_{1}^{a+1}(t+1) = Q_{1}^{a}(t) − x_{1}^{a}(t),   Q_{1}^{0}(t+1) = A_{1}(t+1)")
D.para("A bit that reaches age D without OTP is sent under L2 and counted as a floor violation. D is the recovery-point "
       "deadline. Eq. (18) gives the violated bits in slot t.", indent=False)
eq("viol", "V(t) = Q_{1}^{D−1}(t) − x_{1}^{D−1}(t)")
D.para("The objective in Eq. (19) is lexicographic. The first goal is the share of T1 and commit bits that receive OTP. "
       "Among allocations that achieve it, the second goal rewards T2 OTP and T3 upgrades, with a small weight w_{3}.",
       indent=False)
eq("obj", "maximise  Σ_{t} x_{1}(t) / Σ_{t} A_{1}(t),   then  Σ_{t} [ x_{2}(t) + w_{3} u_{3}(t) ]")
D.para("A simple conservation argument limits what any policy can achieve. It is stated as Lemma 1 and used later to read "
       "the results.", indent=False)
D.para("**Lemma 1** (conservation bound). Over a horizon of T slots, every policy that pays the floors satisfies Eq. (20).")
eq("cons", "C_{1} ≤ [ P(0) + Σ_{t≤T} g(t) − Σ_{t≤T} f(t) ] / Σ_{t≤T} A_{1}(t)")
D.para("*Proof.* Summing Eq. (15) over the horizon and using P(T+1) ≥ 0 gives Σ c(t) ≤ P(0) + Σ g(t). Eq. (16) splits "
       "c(t) into non-negative parts, so Σ x_{1}(t) ≤ P(0) + Σ g(t) − Σ f(t). Dividing by Σ A_{1}(t) yields Eq. (20). Losses at "
       "the pool cap only tighten the bound. ∎", indent=False)
D.para("Eq. (20) shows that no scheduler can create key. A scheduler can only decide where the key goes and avoid waste.",
       indent=False)
D.heading("3.6. Notation", 2)
D.para("The model uses many symbols. Table 3 collects them for reference.")
D.para("Symbols for the link appear first, then those for demand, the pool and the methods.", indent=False)
D.table("Notation.",
        [["Symbol", "Meaning"],
         ["L, α, η", "Fibre length (km); fibre loss (dB/km); overall transmittance"],
         ["μ, Y_{0}, e_{d}", "Mean photon number; background yield; misalignment error"],
         ["R(L), g(t)", "Secret-key rate (bit/s); key generated in slot t (bit)"],
         ["P(t), B_{max}", "Key pool (bit); pool capacity (bit)"],
         ["A_{1}(t), A_{2}(t)", "Arriving T1 + commit bits and T2 bits in slot t"],
         ["Q_{1}^{a}(t)", "T1 + commit bits of age a waiting for OTP"],
         ["S_{2}(t), S_{3}(t)", "Active T2 and T3 streams"],
         ["τ_{min}, τ_{max}", "AES re-key intervals for L2 and L1 (s)"],
         ["D", "Recovery-point deadline for T1 and commit bits (s)"],
         ["H, q_{F}", "TKPF forecast horizon (s); forecast quantile"],
         ["Rsv(t), m(t)", "TKPF key reserve (bit); SLAS mode"],
         ["W_{2}", "Maximum wait of T2 bits for OTP key (s)"]],
        widths=[4.0, 11.9], left_cols=(0, 1))
D.heading("3.7. Assumptions", 2)
D.para("The model rests on five assumptions. Section 7 discusses how each one could affect the results.")
D.bullets(["Each primary region replicates to one secondary site over one dedicated QKD link. The ten links have equal length.",
           "Both key pools stay synchronised, and key identifiers travel with the ciphertext.",
           "The classical channel has enough capacity, so only key availability delays replication.",
           "Tier assignment and the 512-bit commit record are modelling choices.",
           "AES-256 with fresh QKD key is treated as quantum-safe at the strength implied by its key length."])

# ============ 4. Proposed Methods ============
D.heading("4. Proposed Methods", 1)
D.para("This section presents the three methods and proves their main properties. KBRS spends the key, TKPF decides how "
       "much to hold back and SLAS decides when upgrades are allowed.")
D.heading("4.1. KBRS: key-budget-aware replication scheduler", 2)
D.para("KBRS is the allocation core and runs once per second on every link. It serves floors first, then T1 and commit bits, "
       "then upgrades.")
D.para("Algorithm 1 lists the steps. Line 3 adds new key to the pool. Lines 4 and 5 pay the re-key floors of Eq. (16). "
       "Lines 6 to 9 protect waiting T1 and commit bits, oldest first, and may use the whole pool. Lines 10 and 11 set the "
       "upgrade budget. It is the key above the TKPF reserve when SLAS reports the normal mode. Key that would overflow "
       "B_{max} is also spent rather than lost. Line 12 upgrades T3 streams, and line 13 gives OTP to T2 bits. Line 14 applies "
       "the deadline of Eq. (18), and line 15 ages the queues as in Eq. (17).")
D.algorithm("KBRS, one slot of one link",
            ["**Input:** pool P, new key g, queues Q_{1}^{a}, Q_{2}^{a}, streams S_{2}, S_{3}, reserve Rsv, mode m",
             "**Output:** protected bits, violated bits V, updated pool P",
             "P ← P + g",
             "f ← 256 (S_{2}/τ_{min} + S_{3}/τ_{max})",
             "**if** P ≥ f **then** P ← P − f **else** record floor shortfall; P ← 0",
             "**for** a = D − 1 **down to** 0 **do**   ▷ oldest first",
             "    x ← min(Q_{1}^{a}, P)",
             "    protect x bits with OTP;  Q_{1}^{a} ← Q_{1}^{a} − x;  P ← P − x",
             "**end for**",
             "budget ← (P − Rsv) **if** m = normal **else** 0",
             "budget ← max(budget, P + g − B_{max})   ▷ use-or-lose",
             "**if** budget ≥ 256 S_{3}(1/τ_{min} − 1/τ_{max}) **then** re-key T3 every τ_{min}; reduce P and budget",
             "**for** a = W_{2} **down to** 0 **do** protect y = min(Q_{2}^{a}, budget) T2 bits with OTP; reduce P, budget",
             "V ← Q_{1}^{D−1}; send V under L2; send T2 bits older than W_{2} under L2",
             "shift all ages by one slot;  P ← min(P, B_{max});  **return** V, P"])
D.para("**Proposition 1** (oldest-first is optimal for T1). Among policies that spend key only on floors and on T1 and "
       "commit bits, serving the oldest bits first minimises the total violation Σ V(t) of Eq. (18).")
D.para("*Proof.* All bits share the relative deadline D, so the oldest bit always has the earliest deadline. Take a schedule "
       "that serves a younger bit while an older bit waits. Swapping the two leaves total key use unchanged. The older bit "
       "now leaves earlier, and the younger bit still has a later deadline, so it cannot miss where the older one did not. "
       "Repeated swaps reach the oldest-first schedule without adding a violation. This is the exchange argument behind "
       "earliest-deadline-first scheduling [@liu73]. ∎")
D.para("Each slot scans the D age bins of the two queues, so the cost is O(D) per link. With D = 60 and ten links a slot needs "
       "about 1200 simple operations.", indent=False)
D.heading("4.2. TKPF: trace-driven key-pool forecaster", 2)
D.para("TKPF protects future T1 and commit bits from being crowded out by upgrades. It holds back enough key to cover a "
       "forecast burst.")
D.para("At the start of each minute TKPF takes the q_{F}-quantile Â_{q} of per-minute L3 demand over the previous six hours. "
       "Only past data are used, so the forecast is causal. The reserve in Eq. (21) is the forecast shortfall over the "
       "horizon H, plus the bits already waiting.")
eq("rsv", "Rsv(t) = max{ 0,  (H/60) · Â_{q}(t) − R(L) · H } + Σ_{a} Q_{1}^{a}(t)")
D.para("Algorithm 2 lists the steps. Lines 3 to 6 build the causal history of minute demand. Lines 7 to 9 compute the "
       "quantile and the shortfall. Lines 10 to 12 refresh the reserve every second, so it tracks the queue as bits arrive "
       "and leave.", indent=False)
D.algorithm("TKPF, one link",
            ["**Input:** minute demand B_{1}(m), W(m), horizon H, quantile q_{F}, window w = 360 min, key rate R(L)",
             "**Output:** reserve Rsv(t) for every slot",
             "hist ← empty list",
             "**for** each minute m **do**",
             "    d ← B_{1}(m − 1) + 512 W(m − 1)   ▷ last completed minute only",
             "    append d to hist; keep the last w entries",
             "    Â_{q} ← q_{F}-quantile of hist (0 if hist is empty)",
             "    s ← max(0, (H/60) Â_{q} − R(L) H)   ▷ forecast shortfall",
             "    **for** each slot t in minute m **do**",
             "        Rsv(t) ← s + Σ_{a} Q_{1}^{a}(t)",
             "    **end for**",
             "**end for**"])
D.para("**Proposition 2** (protection on arrival). Let g'(s) = g(s) − f(s) be the key left after floors. Suppose that at time t "
       "the pool satisfies P(t) ≥ Σ_{a} Q_{1}^{a}(t) and that, for every s in (t, t + H], the arrivals obey Eq. (22). Then KBRS "
       "protects every T1 and commit bit that arrives in (t, t + H] in its arrival slot.")
eq("arrcond", "Σ_{u=t+1}^{s} A_{1}(u) ≤ P(t) − Σ_{a} Q_{1}^{a}(t) + Σ_{u=t+1}^{s} g'(u)")
D.para("*Proof.* KBRS serves T1 bits before any upgrade (Algorithm 1, lines 6–9). Upgrades never take the pool below "
       "Rsv(t), which is at least the waiting queue. By Eq. (22) the key available up to slot s covers the queue plus all "
       "arrivals so far. No arriving bit finds the pool empty, so each is protected at once. ∎", indent=False)
D.para("TKPF keeps P(t) − Σ_{a} Q_{1}^{a}(t) ≥ (H/60)Â_{q} − R(L)H whenever an upgrade is made. Eq. (22) therefore holds for "
       "any arrival curve that stays below the forecast line. Bursts above the quantile can still cause violations, which the "
       "results quantify.", indent=False)
D.heading("4.3. SLAS: security-level adaptive switching", 2)
D.para("SLAS turns the reserve into a mode of operation. Its hysteresis band stops the link from flapping between modes.")
D.para("SLAS enters the degraded mode when the pool falls below the reserve. It returns to the normal mode only when the pool "
       "exceeds the reserve by 30 s of generation. Eq. (23) states the rule.")
eq("slas", "m(t) ← degraded if P(t) < Rsv(t);   m(t) ← normal if P(t) > Rsv(t) + 30 R(L)")
D.para("Algorithm 3 lists the steps. Lines 3 to 6 apply Eq. (23) and count switches. Lines 7 to 11 set the actions of each "
       "mode. In the degraded mode T3 stays at L1 and T2 receives no OTP, so all spare key protects T1 and commit bits.",
       indent=False)
D.algorithm("SLAS, every slot of one link",
            ["**Input:** mode m, pool P, reserve Rsv, key rate R(L), switch counter n",
             "**Output:** mode m for this slot, updated n",
             "**if** m = normal **and** P < Rsv **then**",
             "    m ← degraded;  n ← n + 1",
             "**else if** m = degraded **and** P > Rsv + 30 R(L) **then**",
             "    m ← normal;  n ← n + 1",
             "**end if**",
             "**if** m = degraded **then**",
             "    hold every T3 stream at L1;  stop OTP for T2",
             "**else**",
             "    allow T3 upgrades and T2 OTP from key above Rsv",
             "**end if**;  **return** m, n"])
D.para("**Proposition 3** (bounded switching). Assume the forecast term of Eq. (21) is fixed and the T1 queue is empty during "
       "an interval, and that g(t) ≤ (1 + ε̄)R(L). Then any two successive degraded-to-normal switches are at least "
       "30/(1 + ε̄) s apart, so the number of switches in T seconds obeys Eq. (24).")
eq("sw", "n(T) ≤ 2 ⌈ T (1 + ε̄) / 30 ⌉")
D.para("*Proof.* Under the assumptions Rsv is constant. A degraded-to-normal switch needs the pool to climb from below Rsv to "
       "above Rsv + 30R(L). In the degraded mode the pool can rise only through generation, at most (1 + ε̄)R(L) per second. "
       "The climb therefore takes at least 30/(1 + ε̄) s. Each such climb allows one switch in each direction, which gives "
       "Eq. (24). ∎ Without hysteresis the mode can change every second, up to 3600 times per hour.", indent=False)
D.heading("4.4. Offline bound", 2)
D.para("An upper bound shows how much room is left for any online method. It is computed by linear programming on the same "
       "data the online methods see.")
D.para("**Proposition 4** (offline bound). Aggregate the slots of one realisation into minutes. Let the L3 and T2 demand of "
       "minute m be served by key from minute m or m + 1, and check the pool cap only at minute boundaries. The linear program "
       "that maximises 1000 x_{1} + x_{2} under these rules gives an upper bound on C_{1} for any online policy that pays the "
       "floors first, on the same realisation.")
D.para("*Proof.* Each constraint of the program relaxes a constraint of the one-second model. The deadline is looser, the "
       "capacity is checked less often and the T3 upgrade is free. Any online schedule is therefore feasible for the program, "
       "and its value cannot exceed the optimum. ∎", indent=False)
D.heading("4.5. Integration", 2)
D.para("The three methods run in a fixed order inside each second. Fig. 2 shows that order.")
D.para("Arrivals and key generation come first. Floors are paid next. TKPF and SLAS then fix the reserve and the mode. KBRS "
       "spends the key, deadlines are applied and the queues age.", indent=False)
D.figure(f"{FIG}/fig2_workflow.png",
         "Order of operations in each one-second slot. Steps 4 and 5 (TKPF, SLAS) gate the upgrades in step 7. Step 6 "
         "(KBRS) may draw on the reserve for T1 and commit bits.")

# ============ 5. Experimental Setup ============
D.heading("5. Experimental Setup", 1)
D.para("This section describes the data, the simulators, the parameters and the baselines. It also defines the metrics and "
       "the software used.")
D.heading("5.1. Dataset", 2)
D.para("The workload is a public trace of real storage accesses. It supplies the timing and size of every write.")
regions = d["regions"]
D.para(f"The Azure Functions blob access trace covers 14 days from November to December 2020 [@azure]. It was released "
       f"with a study of serverless caching [@faast]. It holds {tr['rows']:,} blob accesses from {tr['unique_apps']} "
       f"applications in {tr['regions']} anonymised regions, of which {dem['writes_total']:,} are writes. The ten regions with "
       f"the most T1 and T2 volume were selected. Table 4 lists their demand. Region iic carries most of the T1 volume. "
       f"Region bey carries most of the T2 volume, much of it in multi-gigabit objects.")
import polars as pl
sys.path.insert(0, "/home/claude/hema")
from sw1.sim import load, META_BITS
_, A = load(10, None)
secs = A["writes"].shape[1] * 60
rows = [["Region", "Writes", "T1 + commit (kbit/s)", "T2 (kbit/s)", "Peak minute L3 (kbit/s)"]]
for i, r in enumerate(regions):
    l3 = (A["t1_bits"][i] + A["writes"][i] * META_BITS)
    rows.append([r, f"{int(A['writes'][i].sum()):,}", f"{l3.sum()/secs/1e3:.2f}", f"{A['t2_bits'][i].sum()/secs/1e3:.2f}",
                 f"{(l3/60/1e3).max():.1f}"])
rows.append(["All ten", f"{int(A['writes'].sum()):,}", f"{l3dem/1e3:.2f}", f"{t2dem/1e3:.2f}", "–"])
rows_dem = [r[:] for r in rows]
apt = {x["tier"]: x["len"] for x in dem["apps_per_tier"]}
D.table(f"Replication demand of the ten selected regions (14-day means). Applications per tier over the whole trace: "
        f"T1 {apt[1]}, T2 {apt[2]}, T3 {apt[3]}.", rows, widths=[2.2, 2.6, 3.6, 2.8, 4.0])
D.heading("5.2. QKD simulation", 2)
D.para("The link model of Section 3.2 was checked in a discrete-event quantum-network simulator. The check covers loss "
       "scaling and error rate.")
D.para(f"SeQUeNCe 1.2.0 [@sequence] models the laser, the fibre and the polarisation detectors and runs BB84 sifting. It has "
       f"no privacy-amplification or decoy module, so the secret-key rate itself comes from Eq. (8). The simulator ran fibre of "
       f"1 to 40 km with 0.2 dB/km loss, a mean photon number of 0.5 and an 80 MHz source. The sifted rate fell from "
       f"{seq1['sifted_bps']/1e6:.2f} Mbit/s at 1 km to {seq40['sifted_bps']/1e6:.2f} Mbit/s at 40 km. The QBER stayed "
       f"between {100*qb_lo:.2f}% and {100*qb_hi:.2f}%, below the 1% misalignment error used in Eq. (5). The model is therefore "
       f"conservative. Fig. 3 shows both results. The model gives {mdl[100.0]/1e3:.0f} kbit/s at 100 km and "
       f"{mdl[140.0]/1e3:.1f} kbit/s at 140 km.")
D.figure(f"{FIG}/fig3_keyrate.png",
         "(a) Secret-key rate of the decoy-state model (Eq. (8)) and sifted rate measured in SeQUeNCe, against fibre length. "
         "The two use different source clocks, so only their slopes are comparable. The dashed line marks the main setting. "
         "(b) QBER of the model (Eq. (5), misalignment error 1%) and of SeQUeNCe.")
D.heading("5.3. Region-to-link mapping and record classification", 2)
D.para("Each selected region becomes one primary site with its own link. The link length sets how scarce key is.")
D.para(f"All links share the length L, and the main setting uses L = {L0:.0f} km. At this length the key rate "
       f"({G/1e3:.1f} kbit/s per link) is close to the mean L3 demand of the busiest region. This is the regime in which "
       f"allocation choices matter. Shorter links with slower field equipment give the same ratio of supply to demand, and "
       f"Section 6.6 varies the rate directly. Tiers follow Eq. (10), and arrivals follow Eqs. (11) and (12).")
D.heading("5.4. Parameters", 2)
D.para("All parameters have a source or a stated reason. Most are varied in the sensitivity study.")
D.para("Table 5 lists the parameters and their sources.", indent=False)
D.table("Simulation parameters.",
        [["Parameter", "Value", "Source / reason"],
         ["Fibre loss α", "0.2 dB/km", "Standard single-mode fibre"],
         ["Source clock, μ", "1 GHz, 0.5", "High-rate systems (Section 1)"],
         ["Detector efficiency, Y_{0}", "20%, 10^{−6}", "Typical InGaAs/SNSPD range"],
         ["Misalignment e_{d}, f_{EC}", "1%, 1.16", "Conservative versus SeQUeNCe QBER"],
         ["Key jitter", "5% (Gaussian)", "Assumption, Eq. (9)"],
         ["Pool capacity B_{max}", "600 s of generation", "Varied 60–3600 s"],
         ["Deadline D", "60 s", "Recovery-point objective"],
         ["τ_{min}, τ_{max}", "1 s, 60 s", "Re-key intervals for L2, L1"],
         ["TKPF horizon H, q_{F}", "120 s, 0.95", "Varied 30–600 s, 0.90–0.99"],
         ["T2 maximum wait W_{2}", "0 s", "Varied 0–60 s"],
         ["Link length L", f"{L0:.0f} km", "Varied 40–200 km"],
         ["Replay length, seeds", "14 days, 3 seeds", "Full trace"]],
        widths=[4.5, 3.8, 7.6], left_cols=(0, 2))
D.heading("5.5. Baselines", 2)
D.para("The baselines cover current practice, a static design and two non-QKD references. An offline bound shows the "
       "headroom.")
D.bullets(["**FCFS (ETSI 014 style):** key requests are served in arrival order. T1, commit and T2 requests share one queue.",
           "**Static split:** each tier receives a fixed share of generation, set from its long-run demand.",
           "**AES re-key only:** every stream uses L2, and no OTP is used.",
           "**ML-KEM only:** no QKD key is used. This is a reference level.",
           "**Offline optimum:** the linear-programming bound of Proposition 4, solved with HiGHS [@highs] on the "
           "realisation of seed 1."], numbered=True)
D.heading("5.6. Metrics", 2)
D.para("The metrics measure protection, violations, key use and stability. Coverage of T1 and commit bits is the primary "
       "metric.")
D.para("Eq. (25) defines OTP coverage C_{1}. Eq. (26) defines the violation rate v as the number of seconds with V(t) > 0 "
       "per hour of trace, where 1[·] is the indicator function.", indent=False)
eq("c1", "C_{1} = Σ_{t} x_{1}(t) / Σ_{t} A_{1}(t)")
eq("vr", "v = 3600 · Σ_{t} 1[ V(t) > 0 ] / T")
D.para("Eq. (27) defines key utilisation U and waste Ω. Overflow is the key lost at the cap of Eq. (15). T2 coverage, the "
       "share of T3 stream-seconds at L2, mode switches per hour and replication lag complete the set.", indent=False)
eq("util", "U = Σ_{t} c(t) / Σ_{t} g(t),   Ω = Σ_{t} overflow(t) / Σ_{t} g(t)")
D.heading("5.7. Implementation", 2)
D.para("The simulator is compiled for speed and replays the whole trace in seconds. All policies see identical random "
       "streams.")
D.para(f"The code is written in Python 3.13.16 with NumPy 2.5.3 and Polars 2.0.0. The slot loop is compiled with Numba "
       f"0.68.0 [@numba], and the offline bound uses SciPy 1.18.1 [@scipy]. Runs used a two-core Intel Xeon at 2.8 GHz. A "
       f"14-day replay of one policy took a few seconds, and all "
       f"{len(d['main']) + len(d['distance']) + len(d['sens']) + len(d['defer'])} runs took {d['runtime_s']/60:.0f} min. "
       f"Seeds 1 to 3 drive arrivals and key jitter. Appendix A gives the simulator configuration and the steps to reproduce "
       f"every result.")

# ============ 6. Results ============
D.heading("6. Results and Discussion", 1)
D.para("This section reports the main comparison, then examines time behaviour, distance, per-link effects, ablation and "
       "sensitivity. It closes with the gap to the optimum, significance tests and a discussion.")
D.heading("6.1. Main comparison", 2)
D.para(f"The main setting uses {L0:.0f} km links over the full 14 days. All policies are compared on the same data and "
       f"random streams.")
D.para(f"Table 6 and Fig. 4 give the results. KBRS with TKPF and SLAS protected {pct(cP)}% of T1 and commit bits with OTP. "
       f"FCFS reached {pct(cF)}% and the static split {pct(cS)}%. Floor-violation seconds fell from {vF:.1f} per hour under "
       f"FCFS to {vP:.1f}. The gain has a price. T2 coverage was {pct(M(P,'otp_cov_T2'))}% against "
       f"{pct(M(F,'otp_cov_T2'))}% for FCFS, because key held in reserve is not spent on T2. Waste was high for every policy "
       f"({pct(M(P,'key_waste'))}% for the proposed method). Most of it came from links whose demand was far below supply. "
       f"AES-only and ML-KEM-only runs never met the T1 floor.")
pols = [P, "Proposed w/o KBRS", "Proposed w/o TKPF", "Proposed w/o SLAS", F, ST, "AES re-key only", "ML-KEM only"]
names = ["Proposed (KBRS+TKPF+SLAS)", "w/o KBRS", "w/o TKPF", "w/o SLAS", "FCFS (ETSI 014)", "Static split", "AES re-key only", "ML-KEM only"]
rows = [["Policy", "T1+commit OTP (%)", "T2 OTP (%)", "T3 at L2 (%)", "Violation s/h", "Key used (%)", "Switches/h"]]
for p, n in zip(pols, names):
    rows.append([n, f"{pct(M(p,'otp_cov_T1'),2)} ± {pct(S(p,'otp_cov_T1'),2)}", f"{pct(M(p,'otp_cov_T2'))}",
                 f"{pct(M(p,'t3_L2_share'))}", f"{M(p,'viol_per_hour'):.2f} ± {S(p,'viol_per_hour'):.2f}",
                 f"{pct(M(p,'key_util'))}", f"{M(p,'switches_per_hour'):.2f}"])
rows.append(["Offline optimum (seed 1)", f"{pct(opt,2)}", f"{pct(d['offline_main']['otp_cov_T2'])}", "–", "–", "–", "–"])
D.table(f"Results at L = {L0:.0f} km over 14 days (mean ± standard deviation over three seeds). Coverage follows Eq. (25), "
        f"violations Eq. (26) and key use Eq. (27).", rows,
        widths=[4.2, 3.0, 1.6, 1.6, 2.6, 1.5, 1.6], bold_cells={(1, 1), (1, 4)})
D.figure(f"{FIG}/fig4_main.png",
         f"Main comparison at {L0:.0f} km. (a) OTP coverage of T1 and commit bits; the dashed line is the offline optimum. "
         "(b) Floor-violation seconds per hour. Error bars show the standard deviation over three seeds.")
D.heading("6.2. Demand and supply over time", 2)
D.para("A single day shows how the policies react to bursts. Region iic is used because it carries the most T1 volume.")
D.para("Fig. 5 shows day 5 of region iic. Demand often exceeds the key rate for minutes at a time. Under FCFS the pool drains "
       "at each burst, because T2 requests take key that T1 bits later need. TKPF keeps the pool near its reserve, so T1 bits "
       "find key when a burst arrives. The static split fills its T1 share early and then wastes key, while T1 bits time out "
       "in other minutes.", indent=False)
D.figure(f"{FIG}/fig5_timeseries.png",
         "One day (day 5) of region iic at 140 km. (a) T1 and commit demand in 5-minute means against the QKD key rate. "
         "(b) Key-pool level under three policies and the TKPF reserve of Eq. (21).")
D.heading("6.3. Effect of link distance", 2)
D.para("Link length sets the key rate through Eq. (8). The sweep shows where key budgeting matters.")
D.para(f"Fig. 6 sweeps the length from 40 to 200 km, and Table A.1 in Appendix A lists the exact values. Up to 100 km every "
       f"policy except the static split protects all T1 and commit bits. At 100 km the static split already falls to "
       f"{pct(dist(ST,100.0))}%. The proposed method helps most between 120 and 180 km. At 160 km it covers "
       f"{pct(dist(P,160.0))}% against {pct(dist(F,160.0))}% for FCFS. At 200 km, with {mdl[200.0]:.0f} bit/s of key, Lemma 1 "
       f"leaves little for any policy. The proposed method stays within "
       f"{100*max(dist('Offline optimum',L)-dist(P,L) for L in (120.0,140.0,160.0,180.0,200.0)):.1f} points of the offline "
       f"optimum at every length.", indent=False)
D.figure(f"{FIG}/fig6_distance.png",
         "Effect of link length (100–200 km; below 100 km all policies except the static split reach 100%). (a) OTP coverage "
         "of T1 and commit bits; the offline optimum (dashed) lies almost on the proposed curve. (b) Floor-violation seconds "
         "per hour, log scale.")
D.heading("6.4. Where the gain comes from", 2)
D.para("The ten links differ greatly in demand. Splitting the results by link shows which ones drive the gain.")
pr = json.load(open(f"{RES}/sw1_per_region.json"))
iic = [x for x in pr if x["region"] == "iic"][0]; g4 = [x for x in pr if x["region"] == "4gv"][0]
D.para(f"Table 7 splits the {L0:.0f} km results by link. The gain sits almost entirely on region iic, where mean T1 and "
       f"commit demand ({[r for r in rows_dem if r[0]=='iic'][0][2]} kbit/s) roughly equals the key rate. There the proposed "
       f"method covered {pct(iic[P]['cov'])}% against {pct(iic[F]['cov'])}% for FCFS and halved the violation rate. Region "
       f"ayi gained a little. On the other links key was either plentiful or far too short, and all adaptive policies "
       f"behaved the same. Region 4gv shows the second case. Its few T1 objects are larger than the key pool, so no policy "
       f"covered more than {pct(g4[P]['cov'])}%.", indent=False)
rows = [["Region", "Proposed OTP (%)", "FCFS OTP (%)", "Static OTP (%)", "Proposed viol. s/h", "FCFS viol. s/h", "Key used, proposed (%)"]]
for x in pr:
    rows.append([x["region"], pct(x[P]["cov"], 2), pct(x[F]["cov"], 2), pct(x[ST]["cov"], 2),
                 f"{x[P]['viol']:.2f}", f"{x[F]['viol']:.2f}", pct(x[P]["util"])])
D.table(f"Per-link results at {L0:.0f} km (means over three seeds). OTP: coverage of T1 and commit bits.", rows,
        widths=[1.8, 2.6, 2.3, 2.3, 2.6, 2.3, 2.5])
D.heading("6.5. Ablation study", 2)
D.para("Each component was removed in turn while the others stayed in place. This shows what each one contributes.")
D.para(f"Table 8 gives the result. TKPF carries most of the gain. Without it, coverage drops by "
       f"{100*(cP-M('Proposed w/o TKPF','otp_cov_T1')):.2f} points and violations nearly double. KBRS adds "
       f"{100*dK[0]:.2f} points (95% CI {100*dK[1]:.2f} to {100*dK[2]:.2f}). The effect is small because, with a reserve in "
       f"place, T2 rarely competes with T1. SLAS leaves coverage unchanged. Its role is stability, as Proposition 3 "
       f"predicts. It cuts mode switches by {-dSw[0]:.1f} per hour (95% CI {-dSw[2]:.1f} to {-dSw[1]:.1f}).", indent=False)
rows = [["Variant", "T1+commit OTP (%)", "Δ vs proposed (points)", "Violation s/h", "Switches/h"]]
for p, n in zip(pols[:4], ["Proposed", "w/o KBRS (joint FIFO)", "w/o TKPF (no reserve)", "w/o SLAS (no hysteresis)"]):
    rows.append([n, f"{pct(M(p,'otp_cov_T1'),2)}", "–" if p == P else f"{100*(M(p,'otp_cov_T1')-cP):+.2f}",
                 f"{M(p,'viol_per_hour'):.2f}", f"{M(p,'switches_per_hour'):.2f}"])
D.table(f"Ablation at {L0:.0f} km (means over three seeds).", rows, widths=[5.2, 3.0, 3.4, 2.4, 2.2])
D.heading("6.6. Sensitivity", 2)
D.para("Three factors were varied around the main setting. They are pool size, forecast horizon and key rate.")
D.para(f"Fig. 7 shows the results. A larger pool helps every policy, because it stores key across bursts. With 3600 s of "
       f"storage the proposed method reached {pct(sens('Bmax_s',3600.0,P))}% against {pct(sens('Bmax_s',3600.0,F))}% for "
       f"FCFS. With 60 s the two were close ({pct(sens('Bmax_s',60.0,P))}% and {pct(sens('Bmax_s',60.0,F))}%), since a "
       f"small pool leaves little to reserve. Moving H from 30 s to 120 s raised coverage from {pct(sens('H',30.0,P))}% to "
       f"{pct(sens('H',120.0,P))}% and cut switches from {sens('H',30.0,P,'switches_per_hour'):.1f} to "
       f"{sens('H',120.0,P,'switches_per_hour'):.1f} per hour. The forecast quantile had almost no effect "
       f"({pct(sens('quantile',0.9,P),2)}% at 0.90, {pct(sens('quantile',0.99,P),2)}% at 0.99). Halving the key rate cut "
       f"coverage to {pct(sens('key_scale',0.5,P))}%, and doubling it raised coverage to {pct(sens('key_scale',2.0,P))}%. The "
       f"ranking of policies held in every case.", indent=False)
D.figure(f"{FIG}/fig7_sensitivity.png",
         f"Sensitivity at {L0:.0f} km. (a) Key-pool capacity in seconds of generation. (b) TKPF horizon: coverage and mode "
         "switches. (c) Key-rate scale factor, a proxy for finite-key losses or slower field equipment.")
D.heading("6.7. Replication lag and the value of deferral", 2)
D.para("Waiting for key adds replication lag. This subsection measures that lag and tests whether bulk data should wait.")
lag = {p: np.array([r for r in d['main'] if r['policy'] == p and r['seed'] == 1][0]['lag1_hist']) for p in (P, F, ST)}
z = {p: lag[p][0] / lag[p].sum() for p in lag}
D.para(f"Fig. 8(a) shows how long T1 and commit bits waited for key. Under the proposed method {pct(z[P])}% were protected "
       f"in their arrival second, against {pct(z[F])}% under FCFS and {pct(z[ST])}% under the static split. Fig. 8(b) tests "
       f"deferral of T2 data. Letting T2 wait up to 60 s raised T2 coverage at {L0:.0f} km from "
       f"{pct(defer(140.0,0,P,'otp_cov_T2'),2)}% to {pct(defer(140.0,60,P,'otp_cov_T2'),2)}% and added "
       f"{defer(140.0,60,P,'lag_T2_mean_s'):.1f} s of mean lag. At 60 km the gain was only "
       f"{100*(defer(60.0,60,P,'otp_cov_T2')-defer(60.0,0,P,'otp_cov_T2')):.2f} points. T2 volume is dominated by large objects "
       f"that no realistic budget covers within a minute. Deferral also hurt FCFS, whose T1 coverage fell from "
       f"{pct(defer(140.0,0,F,'otp_cov_T1'))}% to {pct(defer(140.0,60,F,'otp_cov_T1'))}%.", indent=False)
D.figure(f"{FIG}/fig8_lag_defer.png",
         f"(a) Cumulative share of T1 and commit bits against their wait for OTP key at {L0:.0f} km (seed 1). (b) T2 OTP "
         "coverage against mean added replication lag as the maximum T2 wait W_{2} grows from 0 to 60 s, at three link lengths.")
D.heading("6.8. Gap to the optimum and statistical significance", 2)
D.para("Two checks test how strong the results are. One compares the method with the offline bound, and the other tests "
       "whether the gains exceed random variation.")
D.para(f"On the seed-1 realisation at {L0:.0f} km, the offline program of Proposition 4 reached {pct(opt,2)}% and the proposed "
       f"method {pct(p1,2)}%. The online method thus achieved {pct(ratio_opt)}% of the bound. Paired differences against FCFS "
       f"used the same seed for both policies. The coverage gain was {100*dF[0]:.2f} points (95% CI {100*dF[1]:.2f} to "
       f"{100*dF[2]:.2f}). The change in violation rate was {dFv[0]:.2f} s/h (95% CI {dFv[1]:.2f} to {dFv[2]:.2f}). Both "
       f"intervals exclude zero. Three seeds are few, so the intervals use the t-distribution with two degrees of freedom.",
       indent=False)
D.heading("6.9. Discussion", 2)
D.para("The results carry three lessons for operators. They also place QKD budgeting next to post-quantum cryptography.")
D.para("First, key budgeting matters only when key supply and critical demand are of the same order. On short metro links, "
       "QKD supplies far more key than critical records need, and any reasonable policy works. On very long links, Lemma 1 "
       "shows that no policy can help. Operators should size links and key pools for the middle band, where a good scheduler "
       "changes the outcome. Second, the gain comes from reserving key for predictable critical demand, not from clever "
       "ordering. A plain quantile forecast over six hours was enough, and the forecast quantile barely mattered. Third, the "
       "one-time pad is a poor fit for bulk replica data. Real objects are too large, and waiting for key adds lag with "
       "almost no gain. A practical design protects commit records and regulated data with OTP, re-keys AES often for the "
       "rest and moves data without delay. ML-KEM needs no QKD key and protects every tier at a computational level. The "
       "real question for an operator is which data justify information-theoretic protection. The framework here shows how "
       "much of that data a given link can cover and how to spend its key.", indent=False)

# ============ 7. Limitations ============
D.heading("7. Limitations and Threats to Validity", 1)
D.para("The study has limits that bound how far the results can be generalised. Each one points to further work.")
D.bullets(["Key rates come from a simulation model with published parameters, not from a live QKD network. SeQUeNCe checked "
           "loss scaling and error rate but has no privacy-amplification module, so finite-key effects enter only through "
           "the scale factor in Fig. 7(c).",
           "The region-to-link mapping, the tier hash of Eq. (10) and the 512-bit commit record are modelling assumptions. A "
           "different tier mix changes absolute numbers, although the ranking of policies held in every setting tested.",
           "All ten links have the same length. Real deployments mix lengths, and links beyond about 100 km need trusted "
           "relays with their own key demand and trust assumptions.",
           "The trace comes from one provider and covers 14 days. Other workloads may show different burst patterns.",
           "Key waste stays high because each link serves one region. Pooling or relaying key across links would change "
           "this but needs a network model not studied here."])

# ============ 8. Conclusion ============
D.heading("8. Conclusion and Future Work", 1)
D.para("This section summarises the findings with their numbers. It then lists the extensions planned.")
D.para(f"This work treated QKD key as a budget for cloud geo-replication. Three methods were proposed. KBRS allocates key by "
       f"tier and deadline, TKPF holds a forecast-driven reserve and SLAS switches security levels with hysteresis. They were "
       f"tested against 14 days of real Azure storage writes with key rates from a decoy-state model checked in SeQUeNCe. At "
       f"{L0:.0f} km the methods raised OTP coverage of commit and regulated records from {pct(cF)}% under first-come "
       f"delivery to {pct(cP)}%. Floor-violation seconds fell from {vF:.1f} to {vP:.1f} per hour. A static key split covered "
       f"only {pct(cS)}%. The online method reached {pct(ratio_opt)}% of an offline linear-programming bound. The "
       f"forecast-driven reserve gave most of the gain, adding {100*(cP-M('Proposed w/o TKPF','otp_cov_T1')):.2f} points on "
       f"its own. Below 100 km all adaptive policies covered every critical bit, and beyond 180 km none could cover much. "
       f"Deferring bulk data for OTP key added up to {defer(140.0,60,P,'lag_T2_mean_s'):.0f} s of lag for "
       f"{100*(defer(140.0,60,P,'otp_cov_T2')-defer(140.0,0,P,'otp_cov_T2')):.2f} points of coverage, so it is not "
       f"recommended.")
D.para("Three extensions follow. The first is entanglement-based QKD (BBM92) with untrusted relays. It would extend reach "
       "beyond the trusted-node limit and change the key-rate model of Eq. (8). The second is multi-provider traces, which "
       "would test whether the burst patterns and the gain seen here carry over to other clouds. The third is a testbed "
       "deployment, which would replace the modelled key rate with a measured key stream and test the methods against real "
       "link outages.", indent=False)

# ============ Declarations ============
D.heading("CRediT authorship contribution statement", 1)
D.para("[Author One]: Conceptualization, Methodology, Software, Formal analysis, Writing – original draft. [Author Two]: "
       "Supervision, Validation, Writing – review & editing. [Author Three]: Investigation, Visualization. [Edit to match "
       "actual contributions.]", indent=False)
D.heading("Declaration of competing interest", 1)
D.para("The authors declare that they have no known competing financial interests or personal relationships that could have "
       "appeared to influence the work reported in this paper.", indent=False)
D.heading("Funding", 1)
D.para("This research did not receive any specific grant from funding agencies in the public, commercial, or not-for-profit "
       "sectors. [Edit if funded.]", indent=False)
D.heading("Data availability", 1)
D.para("The Azure Functions blob access trace is public (Section 5.1). Simulation code, processed demand files and result "
       "files will be made available in a public repository on acceptance. [Insert repository link.]", indent=False)
D.heading("Declaration of generative AI and AI-assisted technologies in the writing process", 1)
D.para("During the preparation of this work the authors used [name of tool] in order to [purpose]. After using this "
       "tool, the authors reviewed and edited the content as needed and take full responsibility for the content of the "
       "publication. [Complete as required by the journal.]", indent=False)

# ============ Appendix A ============
D.heading("Appendix A. Reproducibility details", 1)
D.para("This appendix gives the numbers behind Fig. 6, the simulator settings and the steps to reproduce the study. It "
       "supports independent checking of every result.")
D.heading("A.1. Distance sweep values", 2)
D.para("The sweep values are listed for seed 1. The offline optimum uses the same realisation as the proposed method.")
D.para("Table A.1 lists the values.", indent=False)
rows = [["L (km)", "Key rate (kbit/s)", "Proposed (%)", "w/o TKPF (%)", "FCFS (%)", "Static (%)", "Offline opt. (%)", "Proposed viol. s/h"]]
for L in (40.0, 60.0, 80.0, 100.0, 120.0, 140.0, 160.0, 180.0, 200.0):
    rows.append([f"{L:.0f}", f"{[r for r in d['distance'] if r['policy']==P and r['L_km']==L][0]['key_rate_bps']/1e3:.2f}",
                 pct(dist(P, L), 2), pct(dist("Proposed w/o TKPF", L), 2), pct(dist(F, L), 2), pct(dist(ST, L), 2),
                 pct(dist("Offline optimum", L), 2), f"{dist(P, L, 'viol_per_hour'):.2f}"])
D.table("OTP coverage of T1 and commit bits against link length (14 days, seed 1).", rows,
        widths=[1.4, 2.2, 2.0, 2.0, 1.8, 1.8, 2.2, 2.5], label="A.1")
D.heading("A.2. SeQUeNCe configuration", 2)
D.para("The simulator settings are given so the link check can be repeated. One unit convention needs care.")
D.para("Table A.2 lists the setup. SeQUeNCe expects fibre attenuation in dB per metre, so 0.2 dB/km must be entered as "
       "2 × 10^{−4}. An earlier run of this study used a natural-log value by mistake. It gave rates that barely fell with "
       "distance and was discarded.", indent=False)
D.table("SeQUeNCe 1.2.0 configuration for the BB84 link check.",
        [["Item", "Setting"],
         ["Nodes", "Two QKDNode instances, BB84 layer only, polarisation encoding"],
         ["Quantum channels", "One in each direction, attenuation 2 × 10^{−4} dB/m, polarisation fidelity 0.99"],
         ["Classical channels", "One in each direction, same length as the fibre"],
         ["Light source", "80 MHz, mean photon number 0.5"],
         ["Run", "20 ms of simulated time per length, key length 256 bit, seed 11"],
         ["Lengths", "1, 5, 10, 20, 30, 40 km"]],
        widths=[3.5, 12.4], left_cols=(0, 1), label="A.2")
D.heading("A.3. Steps to reproduce", 2)
D.para("Five steps rebuild every number and figure. Each step is a script in the released code.")
D.bullets(["Download the Azure Functions blob access trace 2020 and decompress it.",
           "Run the demand extraction to build per-region, per-minute tier demand and stream counts.",
           "Run the SeQUeNCe link check and the decoy-state model to produce the key-rate table.",
           "Run the trace replay for all policies, seeds, lengths and sensitivity settings. The offline bound is solved inside "
           "the same script for seed 1.",
           "Run the figure and manuscript scripts. Every number in the text is read from the result files."], numbered=True)

n_refs = D.references()
out = "/home/claude/hema/sw1/paper/SW1_QKD_KeyBudget_GeoReplication_v2.docx"
D.save(out)
dups = {k: v for k, v in D.cite_count.items() if v > 1}
json.dump({"refs_cited": D.order, "n_refs": n_refs, "figs": D.fig_n, "tables": D.tab_n, "eqs": D.eq_n, "dup_cites": dups},
          open("/home/claude/hema/sw1/paper/build_info_v2.json", "w"), indent=1)
print("saved", out, "refs", n_refs, "figs", D.fig_n, "tables", D.tab_n, "eqs", D.eq_n, "duplicate citations", dups)
print("EQ", EQ)
