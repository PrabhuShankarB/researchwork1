"""Sub-work 1, Experiment B: trace-driven QKD key-budget scheduling for
geo-replication (1-second slots, 14 days, Azure Functions Blob Trace 2020).

Each primary region replicates to one secondary site over one QKD link of
length L. Key supply per second = decoy-state BB84 rate at L (SeQUeNCe-
validated error model) with 5% Gaussian jitter. Key pool capacity = 600 s
of nominal generation.

Security levels (key cost):
  L3 one-time pad                      1 key bit per data bit
  L2 AES-256, QKD re-key every 1 s     256 bits per stream per second
  L1 AES-256, QKD re-key every 60 s    256/60 bits per stream per second
  L0 ML-KEM only                       no QKD key
Tier requirements (floors): T1 payload + all commit records -> L3,
T2 -> L2 (L3 preferred), T3 -> L1 (L2 preferred). Recovery point bound
(RPO) D = 60 s: T1 bits not protected by OTP within D are sent with L2 and
counted as floor violations. T2 bits wait at most W2 = D for OTP, then go L2.

Policies (flags): see POLICIES at the bottom.
"""
import json, os, sys, time
import numpy as np
import polars as pl
from numba import njit

RES = "/home/claude/hema/results"
D = 60
TAU_MIN, TAU_MAX = 1.0, 60.0
META_BITS = 512


def load(top=10, days=None):
    d = pl.read_parquet("/home/claude/data/processed/sw1_demand.parquet")
    regs = (d.group_by("region").agg((pl.col("t1_bits").sum() + pl.col("t2_bits").sum()).alias("q"))
              .sort("q", descending=True)["region"][:top].to_list())
    m0 = d["minute"].min(); m1 = d["minute"].max()
    if days:
        m1 = m0 + days * 1440 - 1
    M = m1 - m0 + 1
    A = {k: np.zeros((len(regs), M)) for k in ("writes", "t1_bits", "t2_bits", "t3_bits", "s1", "s2", "s3")}
    for i, r in enumerate(regs):
        s = d.filter((pl.col("region") == r) & (pl.col("minute") <= m1))
        idx = (s["minute"] - m0).to_numpy()
        for k in A:
            A[k][i, idx] = s[k].to_numpy()
    return regs, A


def reserve_base(A, q=0.95, win=360):
    """Causal rolling q-quantile of per-minute L3 demand (T1 + commit
    records) over the previous `win` minutes (TKPF forecaster input)."""
    l3 = A["t1_bits"] + A["writes"] * META_BITS
    out = np.zeros_like(l3)
    for i in range(l3.shape[0]):
        s = pl.Series(l3[i]).shift(1).fill_null(0.0)
        out[i] = s.rolling_quantile(q, window_size=win, min_samples=1).fill_null(0.0).to_numpy()
    return out


@njit(cache=True)
def run(writes, b1, b2, s2, s3, qbase, G0, Bmax, seed,
        mode, use_reserve, hyst, H, static_f1, static_f2, otp_enabled, W2, tr):
    """mode: 0 KBRS (T1 EDF first, then upgrades)  1 FCFS (T1,T2 jointly
    oldest-first)  2 STATIC (fixed sub-pools)  3 AES-only  4 ML-KEM only."""
    np.random.seed(seed)
    R, M = writes.shape
    S = M * 60
    q1 = np.zeros((R, D)); q2 = np.zeros((R, D))
    P = np.zeros(R); P1 = np.zeros(R); P2 = np.zeros(R); P3 = np.zeros(R)
    for r in range(R):
        P[r] = 0.5 * Bmax[r]
        P1[r] = static_f1 * P[r]; P2[r] = static_f2 * P[r]; P3[r] = P[r] - P1[r] - P2[r]
    degraded = np.zeros(R, np.bool_)
    # accumulators
    l3_tot = 0.0; l3_otp = 0.0; t2_tot = 0.0; t2_otp = 0.0
    t3_ss = 0.0; t3_l2 = 0.0; floor_miss_ss = 0.0; ss_tot = 0.0
    gen = 0.0; used = 0.0; waste = 0.0
    viol_sec = 0.0; switches = 0.0
    lag1 = np.zeros(D + 1); lag2 = np.zeros(D + 1)
    trace = np.zeros((S, 4))   # pool, reserve, L3 arrivals, T2 arrivals for region tr
    real = np.zeros((R, M, 3))  # realised per-minute L3 arrivals, T2 arrivals, key generated
    for t in range(S):
        m = t // 60
        any_viol = False
        for r in range(R):
            # ---- arrivals ----
            w = writes[r, m]
            k = np.random.poisson(w / 60.0) if w > 0 else 0
            frac = k / w if w > 0 else 0.0
            a1 = b1[r, m] * frac + k * META_BITS
            a2 = b2[r, m] * frac
            l3_tot += a1; t2_tot += a2
            real[r, m, 0] += a1; real[r, m, 1] += a2
            q1[r, 0] += a1; q2[r, 0] += a2
            st2 = s2[r, m]; st3 = s3[r, m]
            ss_tot += st2 + st3; t3_ss += st3
            # ---- key generation ----
            g = G0[r] * max(0.0, 1.0 + 0.05 * np.random.randn())   # same random stream for every policy
            if mode == 4:
                g = 0.0
            gen += g
            real[r, m, 2] += g
            if mode == 2:
                P1[r] += static_f1 * g; P2[r] += static_f2 * g; P3[r] += (1 - static_f1 - static_f2) * g
            else:
                P[r] += g
            # ---- floors: re-key costs ----
            c_floor = 256.0 * (st2 / TAU_MIN + st3 / TAU_MAX)
            if mode == 4:
                floor_miss_ss += st2 + st3
            elif mode == 2:
                pay = min(P3[r], c_floor); P3[r] -= pay; used += pay
                if pay < c_floor - 1e-9:
                    floor_miss_ss += (st2 + st3) * (1 - pay / c_floor)
            else:
                pay = min(P[r], c_floor); P[r] -= pay; used += pay
                if pay < c_floor - 1e-9:
                    floor_miss_ss += (st2 + st3) * (1 - pay / c_floor)
            # ---- reserve (TKPF) ----
            rsv = 0.0
            if use_reserve:
                qsum = 0.0
                for a in range(D):
                    qsum += q1[r, a]
                rsv = max(0.0, (H / 60.0) * qbase[r, m] - G0[r] * H) + qsum
            # ---- SLAS mode ----
            if mode == 0 or mode == 1:
                if hyst:
                    if (not degraded[r]) and P[r] < rsv:
                        degraded[r] = True; switches += 1
                    elif degraded[r] and P[r] > rsv + 30.0 * G0[r]:
                        degraded[r] = False; switches += 1
                else:
                    nd = P[r] < rsv
                    if nd != degraded[r]:
                        switches += 1
                    degraded[r] = nd
            # ---- OTP service ----
            if otp_enabled and mode != 4:
                if mode == 0:
                    # T1 earliest-deadline-first, may use the reserve
                    for a in range(D - 1, -1, -1):
                        if q1[r, a] <= 0:
                            continue
                        x = min(q1[r, a], P[r])
                        q1[r, a] -= x; P[r] -= x; used += x; l3_otp += x; lag1[a] += x
                        if P[r] <= 0:
                            break
                    # upgrades only from surplus above reserve, and only if not degraded
                    over = P[r] + G0[r] - Bmax[r]          # use-or-lose
                    budget = P[r] - rsv
                    if degraded[r]:
                        budget = 0.0
                    budget = max(budget, over)
                    if budget > 0:
                        c3 = 256.0 * st3 * (1 / TAU_MIN - 1 / TAU_MAX)
                        if c3 > 0 and budget >= c3:
                            P[r] -= c3; used += c3; budget -= c3; t3_l2 += st3
                        for a in range(D - 1, -1, -1):
                            if budget <= 0:
                                break
                            if q2[r, a] <= 0:
                                continue
                            x = min(q2[r, a], budget)
                            q2[r, a] -= x; P[r] -= x; used += x; budget -= x; t2_otp += x; lag2[a] += x
                elif mode == 1:
                    # FCFS: requests in arrival order across tiers; T3 upgrade requested always
                    c3 = 256.0 * st3 * (1 / TAU_MIN - 1 / TAU_MAX)
                    if P[r] >= c3 and not (use_reserve and degraded[r]):
                        P[r] -= c3; used += c3; t3_l2 += st3
                    for a in range(D - 1, -1, -1):
                        for which in range(2):
                            if which == 1 and use_reserve and (degraded[r] or P[r] <= rsv):
                                continue
                            if P[r] <= 0:
                                break
                            if which == 0:
                                x = min(q1[r, a], P[r]); q1[r, a] -= x; l3_otp += x; lag1[a] += x
                            else:
                                x = min(q2[r, a], P[r]); q2[r, a] -= x; t2_otp += x; lag2[a] += x
                            P[r] -= x; used += x
                elif mode == 2:
                    for a in range(D - 1, -1, -1):
                        x = min(q1[r, a], P1[r]); q1[r, a] -= x; P1[r] -= x; used += x; l3_otp += x; lag1[a] += x
                        x = min(q2[r, a], P2[r]); q2[r, a] -= x; P2[r] -= x; used += x; t2_otp += x; lag2[a] += x
                    c3 = 256.0 * st3 * (1 / TAU_MIN - 1 / TAU_MAX)
                    if P3[r] >= c3:
                        P3[r] -= c3; used += c3; t3_l2 += st3
            elif mode == 3:
                # AES-only: every stream re-keyed each second (L2), no OTP
                c3 = 256.0 * st3 * (1 / TAU_MIN - 1 / TAU_MAX)
                if P[r] >= c3:
                    P[r] -= c3; used += c3; t3_l2 += st3
            # ---- deadlines ----
            if not otp_enabled or mode == 4:
                # no OTP: data leaves at once (no added lag); T1 is below its floor
                for a in range(D):
                    if q1[r, a] > 0:
                        any_viol = True
                    q1[r, a] = 0.0; q2[r, a] = 0.0
            else:
                if q1[r, D - 1] > 0:
                    any_viol = True
                    lag1[D] += q1[r, D - 1]
                if W2 < D:
                    for a in range(W2, D):
                        lag2[W2] += q2[r, a]; q2[r, a] = 0.0
                else:
                    lag2[D] += q2[r, D - 1]
            if r == tr:
                trace[t, 0] = P[r] if mode != 2 else P1[r] + P2[r] + P3[r]
                trace[t, 1] = rsv
                trace[t, 2] = a1
                trace[t, 3] = a2
            for a in range(D - 1, 0, -1):
                q1[r, a] = q1[r, a - 1]; q2[r, a] = q2[r, a - 1]
            q1[r, 0] = 0.0; q2[r, 0] = 0.0
            # ---- pool cap ----
            if mode == 2:
                tot = P1[r] + P2[r] + P3[r]
                if tot > Bmax[r]:
                    sc = Bmax[r] / tot
                    waste += tot - Bmax[r]
                    P1[r] *= sc; P2[r] *= sc; P3[r] *= sc
            elif P[r] > Bmax[r]:
                waste += P[r] - Bmax[r]; P[r] = Bmax[r]
        if any_viol:
            viol_sec += 1
    return (l3_tot, l3_otp, t2_tot, t2_otp, t3_ss, t3_l2, floor_miss_ss, ss_tot,
            gen, used, waste, viol_sec, switches, S, lag1, lag2, trace, real)


def pct(hist, p):
    c = np.cumsum(hist); c = c / max(c[-1], 1e-12)
    return float(np.searchsorted(c, p))


POLICIES = {
    #                        mode reserve hyst otp
    "Proposed":            (0, True,  True,  True),
    "Proposed w/o KBRS":   (1, True,  True,  True),
    "Proposed w/o TKPF":   (0, False, True,  True),
    "Proposed w/o SLAS":   (0, True,  False, True),
    "FCFS (ETSI 014)":     (1, False, False, True),
    "Static split":        (2, False, False, True),
    "AES re-key only":     (3, False, False, False),
    "ML-KEM only":         (4, False, False, False),
}


def evaluate(A, qbase, L_km, policy, seed=1, key_scale=1.0, H=120.0, Bmax_s=600.0, W2=0, tr=-1,
             return_raw=False):
    from sw1.qkd_link import decoy_key_rate
    R = A["writes"].shape[0]
    G = float(decoy_key_rate(L_km)[0]) * key_scale
    G0 = np.full(R, G)
    Bmax = Bmax_s * G0
    l3 = (A["t1_bits"] + A["writes"] * META_BITS).sum(1)
    t2 = A["t2_bits"].sum(1); rk = (256 * (A["s2"] / TAU_MIN + A["s3"] / TAU_MAX) * 60).sum(1)
    tot = np.maximum(l3 + t2 + rk, 1)
    f1, f2 = float((l3 / tot).mean()), float((t2 / tot).mean())
    mode, res, hy, otp = POLICIES[policy]
    o = run(A["writes"], A["t1_bits"], A["t2_bits"], A["s2"], A["s3"], qbase, G0, Bmax,
            seed, mode, res, hy, H, f1, f2, otp, int(W2), int(tr))
    (l3_tot, l3_otp, t2_tot, t2_otp, t3_ss, t3_l2, fm, ss, gen, used, waste, vs, sw, S, lag1, lag2, trace, real) = o
    hours = S / 3600
    nolag = not otp or mode == 4
    return {"policy": policy, "L_km": L_km, "seed": seed, "key_rate_bps": G, "key_scale": key_scale,
            "H": H, "Bmax_s": Bmax_s,
            "otp_cov_T1": l3_otp / max(l3_tot, 1), "otp_cov_T2": t2_otp / max(t2_tot, 1),
            "t3_L2_share": t3_l2 / max(t3_ss, 1), "rekey_floor_miss": fm / max(ss, 1),
            "floor_viol_bits": 1 - l3_otp / max(l3_tot, 1),
            "time_below_floor": vs / S, "viol_per_hour": vs / hours,
            "key_util": used / max(gen, 1), "key_waste": waste / max(gen, 1),
            "switches_per_hour": sw / hours,
            "lag_T1_p50_s": 0.0 if nolag else pct(lag1, .5), "lag_T1_p99_s": 0.0 if nolag else pct(lag1, .99),
            "lag_T2_p50_s": 0.0 if nolag else pct(lag2, .5), "lag_T2_p99_s": 0.0 if nolag else pct(lag2, .99),
            "lag_T2_mean_s": 0.0 if nolag else float((lag2 * np.arange(D + 1)).sum() / max(lag2.sum(), 1e-12)),
            "l3_demand_bps": l3_tot / S, "t2_demand_bps": t2_tot / S, "W2": W2,
            **({"lag1_hist": lag1.tolist(), "lag2_hist": lag2.tolist(), "trace": trace, "real": real} if return_raw else {})}


if __name__ == "__main__":
    days = int(sys.argv[1]) if len(sys.argv) > 1 else 1
    regs, A = load(10, days)
    qb = reserve_base(A)
    for L in [float(x) for x in sys.argv[2].split(",")] if len(sys.argv) > 2 else (100.0,):
        for p in [x for x in POLICIES if (len(sys.argv) < 4 or x in sys.argv[3].split("|"))]:
            t0 = time.time()
            r = evaluate(A, qb, L, p)
            keys = ("key_rate_bps", "otp_cov_T1", "otp_cov_T2", "t3_L2_share", "rekey_floor_miss", "viol_per_hour",
                    "key_util", "key_waste", "switches_per_hour", "lag_T2_mean_s", "lag_T2_p99_s")
            print(f"L={L:5.0f} {p:20s}", {k: round(r[k], 4) for k in keys}, f"{time.time()-t0:.1f}s", flush=True)
