"""python-docx helpers: Elsevier-style layout, citations with internal
hyperlinks, DOI hyperlinks, three-line tables, numbered equations."""
import re
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING, WD_TAB_ALIGNMENT, WD_BREAK
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

FONT = "Times New Roman"


class Doc:
    def __init__(self, refs, spacing=1.5):
        self.d = Document()
        self.refs = refs
        self.order = []          # citation keys in order of first appearance
        self.cite_count = {}
        self.spacing = spacing
        sec = self.d.sections[0]
        sec.page_height, sec.page_width = Cm(29.7), Cm(21.0)
        for m in ("left_margin", "right_margin", "top_margin", "bottom_margin"):
            setattr(sec, m, Cm(2.54))
        st = self.d.styles["Normal"]
        st.font.name = FONT; st.font.size = Pt(12)
        st.element.rPr.rFonts.set(qn("w:eastAsia"), FONT)
        pf = st.paragraph_format
        pf.line_spacing = spacing; pf.space_after = Pt(6); pf.space_before = Pt(0)
        for h, sz, it in (("Heading 1", 12, False), ("Heading 2", 12, True), ("Heading 3", 12, True)):
            s = self.d.styles[h]
            s.font.name = FONT; s.font.size = Pt(sz); s.font.bold = h != "Heading 3"; s.font.italic = it
            s.font.color.rgb = RGBColor(0, 0, 0)
            s.element.rPr.rFonts.set(qn("w:eastAsia"), FONT)
            rf = s.element.rPr.find(qn("w:rFonts"))
            for a in ("w:ascii", "w:hAnsi", "w:cs"):
                rf.set(qn(a), FONT)
            s.paragraph_format.space_before = Pt(12); s.paragraph_format.space_after = Pt(6)
            s.paragraph_format.line_spacing = spacing; s.paragraph_format.keep_with_next = True
        self._line_numbers(sec)
        self._page_numbers(sec)
        self.fig_n = 0; self.tab_n = 0; self.eq_n = 0; self.alg_n = 0

    # ---------- page furniture ----------
    def _line_numbers(self, sec):
        ln = OxmlElement("w:lnNumType")
        ln.set(qn("w:countBy"), "1"); ln.set(qn("w:restart"), "continuous"); ln.set(qn("w:distance"), "283")
        sec._sectPr.append(ln)

    def _page_numbers(self, sec):
        p = sec.footer.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = p.add_run()
        for t, txt in (("begin", None), (None, "PAGE"), ("end", None)):
            if t:
                fc = OxmlElement("w:fldChar"); fc.set(qn("w:fldCharType"), t); r._r.append(fc)
            else:
                it = OxmlElement("w:instrText"); it.set(qn("xml:space"), "preserve"); it.text = txt; r._r.append(it)
        r.font.size = Pt(10); r.font.name = FONT

    # ---------- inline text with citations and simple markup ----------
    def _cite_numbers(self, keys):
        nums = []
        for k in keys:
            if k not in self.refs:
                raise KeyError(f"unknown reference {k}")
            self.cite_count[k] = self.cite_count.get(k, 0) + 1
            if k not in self.order:
                self.order.append(k)
            nums.append(self.order.index(k) + 1)
        return sorted(set(nums))

    def _add_link_run(self, par, text, anchor=None, url=None, size=None, italic=False):
        h = OxmlElement("w:hyperlink")
        if anchor:
            h.set(qn("w:anchor"), anchor)
        else:
            rid = par.part.relate_to(url, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink",
                                     is_external=True)
            h.set(qn("r:id"), rid)
        r = OxmlElement("w:r"); rp = OxmlElement("w:rPr")
        f = OxmlElement("w:rFonts")
        for a in ("w:ascii", "w:hAnsi", "w:cs"):
            f.set(qn(a), FONT)
        rp.append(f)
        c = OxmlElement("w:color"); c.set(qn("w:val"), "1F4E79"); rp.append(c)
        if url:
            u = OxmlElement("w:u"); u.set(qn("w:val"), "single"); rp.append(u)
        if size:
            sz = OxmlElement("w:sz"); sz.set(qn("w:val"), str(int(size * 2))); rp.append(sz)
        if italic:
            rp.append(OxmlElement("w:i"))
        r.append(rp)
        t = OxmlElement("w:t"); t.set(qn("xml:space"), "preserve"); t.text = text; r.append(t)
        h.append(r); par._p.append(h)

    def _ranges(self, nums):
        out, i = [], 0
        while i < len(nums):
            j = i
            while j + 1 < len(nums) and nums[j + 1] == nums[j] + 1:
                j += 1
            out.append((nums[i], nums[j]))
            i = j + 1
        return out

    def text(self, par, s, size=None, italic=False, bold=False):
        """Supports [@k1,@k2] citations, **bold**, *italic*, _{sub}, ^{sup}."""
        tokens = re.split(r"(\[@[^\]]+\]|\*\*[^*]+\*\*|\*[^*]+\*|_\{[^}]*\}|\^\{[^}]*\})", s)
        for tk in tokens:
            if not tk:
                continue
            if tk.startswith("[@"):
                keys = [k.strip().lstrip("@") for k in tk[1:-1].split(",")]
                nums = self._cite_numbers(keys)
                for gi, (a, b) in enumerate(self._ranges(nums)):
                    if gi:
                        self._run(par, ", ", size)
                    self._add_link_run(par, f"[{a}]", anchor=f"ref{a}", size=size)
                    if b > a:
                        self._run(par, "–", size)
                        self._add_link_run(par, f"[{b}]", anchor=f"ref{b}", size=size)
            elif tk.startswith("**"):
                self._run(par, tk[2:-2], size, bold=True, italic=italic)
            elif tk.startswith("*"):
                self._run(par, tk[1:-1], size, italic=True, bold=bold)
            elif tk.startswith("_{"):
                r = self._run(par, tk[2:-1], size, italic=italic, bold=bold); r.font.subscript = True
            elif tk.startswith("^{"):
                r = self._run(par, tk[2:-1], size, italic=italic, bold=bold); r.font.superscript = True
            else:
                self._run(par, tk, size, italic=italic, bold=bold)
        return par

    def _run(self, par, t, size=None, bold=False, italic=False):
        r = par.add_run(t); r.font.name = FONT
        if size:
            r.font.size = Pt(size)
        r.bold = bold or None; r.italic = italic or None
        return r

    # ---------- blocks ----------
    def para(self, s, align="justify", indent=True, size=None, italic=False, space_after=6):
        p = self.d.add_paragraph()
        p.alignment = {"justify": WD_ALIGN_PARAGRAPH.JUSTIFY, "center": WD_ALIGN_PARAGRAPH.CENTER,
                       "left": WD_ALIGN_PARAGRAPH.LEFT}[align]
        if indent:
            p.paragraph_format.first_line_indent = Cm(0.5)
        p.paragraph_format.space_after = Pt(space_after)
        return self.text(p, s, size=size, italic=italic)

    def heading(self, s, level=1):
        h = self.d.add_heading(level=level)
        self.text(h, s)
        return h

    def bullets(self, items, numbered=False):
        for i, it in enumerate(items, 1):
            p = self.d.add_paragraph()
            p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
            p.paragraph_format.left_indent = Cm(0.9); p.paragraph_format.first_line_indent = Cm(-0.5)
            p.paragraph_format.space_after = Pt(3)
            self._run(p, f"{i}.  " if numbered else "•  ")
            self.text(p, it)

    def equation(self, s):
        self.eq_n += 1
        p = self.d.add_paragraph()
        p.paragraph_format.tab_stops.add_tab_stop(Cm(7.96), WD_TAB_ALIGNMENT.CENTER)
        p.paragraph_format.tab_stops.add_tab_stop(Cm(15.9), WD_TAB_ALIGNMENT.RIGHT)
        p.paragraph_format.space_before = Pt(3); p.paragraph_format.space_after = Pt(6)
        self._run(p, "\t")
        tokens = re.split(r"(_\{[^}]*\}|\^\{[^}]*\})", s)
        for tk in tokens:
            if not tk:
                continue
            if tk.startswith("_{"):
                r = self._run(p, tk[2:-1]); r.font.subscript = True
            elif tk.startswith("^{"):
                r = self._run(p, tk[2:-1]); r.font.superscript = True
            else:
                self._run(p, tk)
        for r in p.runs:
            r.font.size = Pt(11)
            r.font.name = "Cambria Math"
            r._r.get_or_add_rPr().get_or_add_rFonts().set(qn("w:hAnsi"), "Cambria Math")
        self._run(p, f"\t({self.eq_n})")
        return self.eq_n

    def figure(self, path, caption, width_cm=16.0):
        self.fig_n += 1
        p = self.d.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.keep_with_next = True; p.paragraph_format.space_before = Pt(6)
        p.add_run().add_picture(path, width=Cm(width_cm))
        c = self.d.add_paragraph(); c.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        c.paragraph_format.line_spacing = 1.0; c.paragraph_format.space_after = Pt(12)
        self._run(c, f"Fig. {self.fig_n}. ", size=10, bold=True)
        self.text(c, caption, size=10)
        return self.fig_n

    def _borders(self, cell, top=None, bottom=None):
        tcPr = cell._tc.get_or_add_tcPr()
        b = OxmlElement("w:tcBorders")
        for side, val in (("top", top), ("bottom", bottom), ("left", None), ("right", None)):
            e = OxmlElement(f"w:{side}")
            if val:
                e.set(qn("w:val"), "single"); e.set(qn("w:sz"), str(val)); e.set(qn("w:color"), "000000")
            else:
                e.set(qn("w:val"), "nil")
            b.append(e)
        tcPr.append(b)

    def table(self, caption, rows, widths=None, bold_cells=(), notes=None, size=9.5, left_cols=(0,), label=None):
        if label is None:
            self.tab_n += 1
            label = str(self.tab_n)
        c = self.d.add_paragraph(); c.alignment = WD_ALIGN_PARAGRAPH.LEFT
        c.paragraph_format.line_spacing = 1.0; c.paragraph_format.keep_with_next = True
        c.paragraph_format.space_before = Pt(8)
        self._run(c, f"Table {label}. ", size=10, bold=True)
        self.text(c, caption, size=10)
        t = self.d.add_table(rows=len(rows), cols=len(rows[0]))
        t.alignment = WD_TABLE_ALIGNMENT.CENTER
        tblPr = t._tbl.tblPr
        tb = OxmlElement("w:tblBorders")
        for side in ("top", "left", "bottom", "right", "insideH", "insideV"):
            e = OxmlElement(f"w:{side}"); e.set(qn("w:val"), "nil"); tb.append(e)
        tblPr.append(tb)
        if widths:
            lay = OxmlElement("w:tblLayout"); lay.set(qn("w:type"), "fixed"); tblPr.append(lay)
            grid = t._tbl.tblGrid
            for gc, wcm in zip(grid.findall(qn("w:gridCol")), widths):
                gc.set(qn("w:w"), str(int(wcm * 567)))
        n = len(rows)
        for i, row in enumerate(rows):
            for j, v in enumerate(row):
                cell = t.cell(i, j)
                cell.text = ""
                p = cell.paragraphs[0]
                p.paragraph_format.line_spacing = 1.0; p.paragraph_format.space_after = Pt(1)
                p.alignment = WD_ALIGN_PARAGRAPH.LEFT if j in left_cols else WD_ALIGN_PARAGRAPH.CENTER
                self.text(p, str(v), size=size, bold=(i == 0 or (i, j) in bold_cells))
                top = 12 if i == 0 else None
                bottom = 6 if i == 0 else (12 if i == n - 1 else None)
                self._borders(cell, top, bottom)
                if widths:
                    cell.width = Cm(widths[j])
            trPr = t.rows[i]._tr.get_or_add_trPr()
            cs = OxmlElement("w:cantSplit"); trPr.append(cs)
            if i < n - 1:
                for c in t.rows[i].cells:
                    for pp in c.paragraphs:
                        pp.paragraph_format.keep_with_next = True
        if notes:
            p = self.d.add_paragraph(); p.paragraph_format.line_spacing = 1.0
            self.text(p, notes, size=9)
        else:
            self.d.add_paragraph().paragraph_format.space_after = Pt(2)
        return self.tab_n

    def algorithm(self, title, lines):
        self.alg_n += 1
        t = self.d.add_table(rows=1, cols=1)
        t.alignment = WD_TABLE_ALIGNMENT.CENTER
        cell = t.cell(0, 0)
        t.rows[0]._tr.get_or_add_trPr().append(OxmlElement("w:cantSplit"))
        tcPr = cell._tc.get_or_add_tcPr()
        b = OxmlElement("w:tcBorders")
        for side in ("top", "bottom", "left", "right"):
            e = OxmlElement(f"w:{side}"); e.set(qn("w:val"), "single"); e.set(qn("w:sz"), "8"); b.append(e)
        tcPr.append(b)
        p = cell.paragraphs[0]; p.paragraph_format.line_spacing = 1.0
        self._run(p, f"Algorithm {self.alg_n}. ", size=10, bold=True); self.text(p, title, size=10)
        for i, ln in enumerate(lines, 1):
            q = cell.add_paragraph(); q.paragraph_format.line_spacing = 1.0; q.paragraph_format.space_after = Pt(0)
            ind = len(ln) - len(ln.lstrip(" "))
            q.paragraph_format.left_indent = Cm(0.8 + 0.4 * (ind // 2)); q.paragraph_format.first_line_indent = Cm(-0.8)
            self._run(q, f"{i:>2}:  ", size=9.5)
            self.text(q, ln.strip(), size=9.5)
        self.d.add_paragraph().paragraph_format.space_after = Pt(2)
        return self.alg_n

    def references(self):
        self.heading("References", 1)
        for i, k in enumerate(self.order, 1):
            e = self.refs[k]
            authors, title, venue, doi = e[0], e[1], e[2], e[3]
            url = e[4] if len(e) > 4 else None
            p = self.d.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
            p.paragraph_format.left_indent = Cm(0.9); p.paragraph_format.first_line_indent = Cm(-0.9)
            p.paragraph_format.line_spacing = 1.0; p.paragraph_format.space_after = Pt(3)
            bs = OxmlElement("w:bookmarkStart"); bs.set(qn("w:id"), str(i)); bs.set(qn("w:name"), f"ref{i}")
            p._p.append(bs)
            self._run(p, f"[{i}]\t", size=10)
            be = OxmlElement("w:bookmarkEnd"); be.set(qn("w:id"), str(i)); p._p.append(be)
            self._run(p, f"{authors}, “{title},” ", size=10)
            ven = venue
            self._run(p, ven + ", ", size=10, italic=False)
            if doi:
                self._run(p, "doi: ", size=10)
                self._add_link_run(p, doi, url=f"https://doi.org/{doi}", size=10)
                self._run(p, ".", size=10)
            else:
                self._run(p, "[Online]. Available: ", size=10)
                self._add_link_run(p, url, url=url, size=10)
        return len(self.order)

    def page_break(self):
        self.d.add_paragraph().add_run().add_break(WD_BREAK.PAGE)

    def save(self, path):
        self.d.save(path)
