"""Sub-work 1, Experiment A: BB84 link simulation in SeQUeNCe 1.2.0.

SeQUeNCe simulates the physical layer (laser, fibre attenuation, polarisation
detectors with dark counts) and BB84 sifting. It returns the sifted-key
throughput and the quantum bit error rate (QBER). SeQUeNCe has no privacy
amplification or decoy-state module, so the final secret-key rate is
computed with the asymptotic decoy-state GLLP bound (Lo, Ma, Chen 2005):

    R = q * { Q1 * [1 - h2(e1)] - Q_mu * f * h2(E_mu) }

using the standard infinite-decoy estimates of Q1 and e1. The SeQUeNCe QBER
is used to validate the analytic error model at short distances.
"""
import json, math, sys
import numpy as np
from sequence.kernel.timeline import Timeline
from sequence.topology.node import QKDNode
from sequence.components.optical_channel import QuantumChannel, ClassicalChannel
from sequence.qkd.BB84 import pair_bb84_protocols


class KeyParent:
    """Upper-layer stub that receives finished keys from BB84."""
    def __init__(self, own):
        self.own = own
        self.keys = []

    def pop(self, info=None, **kw):
        self.keys.append(info)

    def get_key_from_BB84(self, info):
        self.keys.append(info)

    def received_message(self, *a):
        pass


def seq_bb84(dist_km, sim_s=0.02, freq=8e7, keylen=256, seed=1, atten_db_km=0.2):
    tl = Timeline(int(sim_s * 1e12) + int(1e10))
    tl.show_progress = False
    a = QKDNode("alice", tl, stack_size=1, seed=seed)
    b = QKDNode("bob", tl, stack_size=1, seed=seed + 7)
    pair_bb84_protocols(a.protocol_stack[0], b.protocol_stack[0])
    alpha = atten_db_km / 1000                              # SeQUeNCe unit: dB per metre
    qc = QuantumChannel("qc", tl, attenuation=alpha, distance=dist_km * 1000,
                        polarization_fidelity=0.99)
    qc.set_ends(a, b.name)
    qc2 = QuantumChannel("qc2", tl, attenuation=alpha, distance=dist_km * 1000,
                         polarization_fidelity=0.99)
    qc2.set_ends(b, a.name)                                 # BB84 reads delay from both ends
    for s, d in ((a, b), (b, a)):
        cc = ClassicalChannel(f"cc_{s.name}", tl, distance=dist_km * 1000)
        cc.set_ends(s, d.name)
    a.components["alice.lightsource"].frequency = freq
    a.components["alice.lightsource"].mean_photon_num = 0.5
    pa = KeyParent(a)
    a.protocol_stack[0].upper_protocols.append(pa)
    pa_b = KeyParent(b)
    b.protocol_stack[0].upper_protocols.append(pa_b)
    tl.init()
    a.protocol_stack[0].push(keylen, 10**6, int(sim_s * 1e12))
    tl.run()
    p = a.protocol_stack[0]
    thr = np.mean(p.throughputs) if p.throughputs else 0.0
    err = np.mean(p.error_rates) if p.error_rates else float("nan")
    return {"dist_km": dist_km, "sifted_bps": float(thr), "qber": float(err),
            "keys": len(p.throughputs)}


# ---------------- analytic decoy-state model (GLLP, infinite decoys) ----------
def h2(x):
    x = np.clip(x, 1e-12, 1 - 1e-12)
    return -x * np.log2(x) - (1 - x) * np.log2(1 - x)


def decoy_key_rate(L_km, mu=0.5, eta_det=0.20, Y0=1e-6, e_d=0.01, f_ec=1.16,
                   alpha=0.2, eta_bob=1.0, clock=1e9, q=0.5):
    """Secret-key bits per second for decoy-state BB84 over L km of fibre.
    Default detector values follow Lo, Ma & Chen (2005), Table I style
    parameters for InGaAs detectors; clock 1 GHz as in recent metro systems."""
    eta = 10 ** (-alpha * L_km / 10) * eta_det * eta_bob
    Q_mu = Y0 + 1 - np.exp(-eta * mu)
    E_mu = (0.5 * Y0 + e_d * (1 - np.exp(-eta * mu))) / Q_mu
    Y1 = Y0 + eta
    Q1 = Y1 * mu * np.exp(-mu)
    e1 = (0.5 * Y0 + e_d * eta) / Y1
    R = q * (Q1 * (1 - h2(e1)) - Q_mu * f_ec * h2(E_mu))
    return np.maximum(R, 0.0) * clock, E_mu


if __name__ == "__main__":
    out = {"seq": [], "model": []}
    for d in (1, 5, 10, 20, 30, 40):
        r = seq_bb84(d, seed=11)
        out["seq"].append(r)
        print("SeQUeNCe", r, flush=True)
    for d in np.arange(0, 201, 5):
        R, E = decoy_key_rate(float(d))
        out["model"].append({"dist_km": float(d), "skr_bps": float(R), "qber": float(E)})
    print([(m["dist_km"], round(m["skr_bps"])) for m in out["model"][::4]])
    json.dump(out, open("/home/claude/hema/results/sw1_qkd_link.json", "w"), indent=1)
