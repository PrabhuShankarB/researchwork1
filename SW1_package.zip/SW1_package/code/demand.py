"""Per-region, per-minute replication demand by sensitivity tier, from the
full Azure Functions Blob Access Trace 2020 (writes only).

Tier assignment (modelling assumption, stated in the paper): each
application is assigned once, by a fixed hash of its anonymised name,
  T1 regulated    10% of apps  - payload must use one-time pad (L3)
  T2 confidential 20% of apps  - one-time pad preferred, AES-256 (L2) accepted
  T3 standard     70% of apps  - AES-256 with QKD re-keying (L1 or better)
Every write also produces a 512-bit commit/metadata record (always L3).
"""
import json
import polars as pl

SRC = "/home/claude/data/blob2020.csv"
OUT = "/home/claude/data/processed/sw1_demand.parquet"

lf = (pl.scan_csv(SRC, schema_overrides={"AnonUserId": pl.Utf8, "AnonFunctionInvocationId": pl.Utf8})
      .select([(pl.col("Timestamp") // 60000).alias("minute"),
               pl.col("AnonRegion").alias("region"),
               pl.col("AnonAppName").alias("app"),
               pl.col("BlobBytes").cast(pl.Float64).alias("bytes"),
               pl.col("Write").cast(pl.Boolean).alias("w")])
      .filter(pl.col("w")))
h = pl.col("app").hash(seed=2026) % 100
lf = lf.with_columns(pl.when(h < 10).then(1).when(h < 30).then(2).otherwise(3).alias("tier"))
agg = (lf.group_by(["region", "minute"]).agg([
        pl.len().alias("writes"),
        (pl.col("bytes").filter(pl.col("tier") == 1).sum() * 8).alias("t1_bits"),
        (pl.col("bytes").filter(pl.col("tier") == 2).sum() * 8).alias("t2_bits"),
        (pl.col("bytes").filter(pl.col("tier") == 3).sum() * 8).alias("t3_bits"),
        pl.col("app").n_unique().alias("streams"),
        pl.col("app").filter(pl.col("tier") == 1).n_unique().alias("s1"),
        pl.col("app").filter(pl.col("tier") == 2).n_unique().alias("s2"),
        pl.col("app").filter(pl.col("tier") == 3).n_unique().alias("s3")])
      .sort(["region", "minute"]).collect(engine="streaming"))
agg.write_parquet(OUT)
apps = lf.select(["app", "tier"]).unique().collect(engine="streaming")
summ = {"rows": agg.height,
        "apps_per_tier": apps.group_by("tier").len().sort("tier").to_dicts(),
        "bits_per_tier_total": {t: float(agg[f"t{t}_bits"].sum()) for t in (1, 2, 3)},
        "writes_total": int(agg["writes"].sum())}
print(json.dumps(summ, indent=1))
reg = (agg.group_by("region").agg(pl.col("writes").sum(), (pl.col("t1_bits").sum() / 1e9).alias("t1_Gb"),
       (pl.col("t2_bits").sum() / 1e9).alias("t2_Gb"), (pl.col("t3_bits").sum() / 1e9).alias("t3_Gb"))
       .sort("writes", descending=True))
pl.Config.set_tbl_rows(30); print(reg)
json.dump(summ, open("/home/claude/hema/results/sw1_demand_summary.json", "w"), indent=1)
