"""Fig. 1 (architecture) and Fig. 2 (per-slot workflow) for Sub-work 1."""
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

OUT = "/home/claude/hema/sw1/figs"
os.makedirs(OUT, exist_ok=True)
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8})
INK, MUTED = "#1b1b1b", "#555555"
BLUE, ORANGE, GREEN, GREY, PURPLE = "#d6e6f8", "#fde3d4", "#d5f2e6", "#ededeb", "#e4e0f6"
EDGE = {"b": "#2a78d6", "o": "#eb6834", "g": "#1baf7a", "k": "#777777", "p": "#4a3aa7"}


def box(ax, x, y, w, h, text, fc, ec, fs=8, bold=False):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.01,rounding_size=0.015",
                                fc=fc, ec=ec, lw=1.0))
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=fs, color=INK,
            fontweight="bold" if bold else "normal", linespacing=1.25)


def arrow(ax, x1, y1, x2, y2, txt=None, color=INK, style="-|>", ls="-", off=(0, 0.012)):
    ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle=style, mutation_scale=9,
                                 lw=1.0, color=color, linestyle=ls))
    if txt:
        ax.text((x1 + x2) / 2 + off[0], (y1 + y2) / 2 + off[1], txt, ha="center", va="bottom",
                fontsize=7, color=MUTED)


def save(fig, name):
    fig.savefig(f"{OUT}/{name}.png", dpi=600, bbox_inches="tight", pad_inches=0.02)
    fig.savefig(f"{OUT}/{name}.pdf", bbox_inches="tight", pad_inches=0.02)
    fig.savefig(f"{OUT}/{name}.tiff", dpi=1000, bbox_inches="tight", pad_inches=0.02,
                pil_kwargs={"compression": "tiff_lzw"})
    plt.close(fig)


# ---------------- Fig. 1: architecture ----------------
fig, ax = plt.subplots(figsize=(7.48, 4.2))
ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")
FS = 7
box(ax, 0.005, 0.03, 0.335, 0.94, "", "#fafaf8", EDGE["k"])
ax.text(0.1725, 0.935, "Primary data centre", ha="center", fontsize=8, fontweight="bold")
box(ax, 0.66, 0.03, 0.335, 0.94, "", "#fafaf8", EDGE["k"])
ax.text(0.8275, 0.935, "Secondary data centre", ha="center", fontsize=8, fontweight="bold")
box(ax, 0.025, 0.72, 0.295, 0.17, "Replication layer\nT1, T2, T3 writes\n+ commit records", BLUE, EDGE["b"], fs=FS)
box(ax, 0.025, 0.27, 0.295, 0.40, "", PURPLE, EDGE["p"])
ax.text(0.1725, 0.635, "Key management layer", ha="center", fontsize=FS, fontweight="bold")
box(ax, 0.045, 0.51, 0.255, 0.085, "TKPF: forecast and\nkey reserve", "#ffffff", EDGE["p"], fs=FS)
box(ax, 0.045, 0.40, 0.255, 0.085, "KBRS: tier-aware\nkey allocation", "#ffffff", EDGE["p"], fs=FS)
box(ax, 0.045, 0.29, 0.255, 0.085, "SLAS: security level\nwith hysteresis", "#ffffff", EDGE["p"], fs=FS)
box(ax, 0.025, 0.06, 0.295, 0.16, "Encryption engine\nOTP (L3), AES-256\nre-keyed 1 s / 60 s", GREEN, EDGE["g"], fs=FS)
box(ax, 0.68, 0.72, 0.27, 0.17, "Replica store\ndecrypt, verify,\ncommit", BLUE, EDGE["b"], fs=FS)
box(ax, 0.68, 0.37, 0.27, 0.20, "Key pool (mirror)\nsame key bits,\nindexed by key ID", PURPLE, EDGE["p"], fs=FS)
box(ax, 0.68, 0.06, 0.27, 0.16, "Decryption engine", GREEN, EDGE["g"], fs=FS)
box(ax, 0.39, 0.40, 0.22, 0.18, "QKD link\nBB84, decoy state\nfibre L km, rate R(L)", ORANGE, EDGE["o"], fs=FS)
box(ax, 0.39, 0.08, 0.22, 0.12, "Classical channel\nciphertext + key IDs", GREY, EDGE["k"], fs=FS)
arrow(ax, 0.1725, 0.72, 0.1725, 0.67, color=EDGE["b"])
arrow(ax, 0.1725, 0.27, 0.1725, 0.22, color=EDGE["p"])
arrow(ax, 0.32, 0.14, 0.39, 0.14)
arrow(ax, 0.61, 0.14, 0.68, 0.14)
arrow(ax, 0.39, 0.49, 0.32, 0.49, color=EDGE["o"])
arrow(ax, 0.61, 0.49, 0.68, 0.49, color=EDGE["o"])
ax.text(0.355, 0.505, "key", ha="center", fontsize=6.5, color=MUTED)
ax.text(0.645, 0.505, "key", ha="center", fontsize=6.5, color=MUTED)
arrow(ax, 0.815, 0.37, 0.815, 0.22, color=EDGE["p"])
ax.plot([0.95, 0.975, 0.975], [0.14, 0.14, 0.805], color=EDGE["g"], lw=1.0)
arrow(ax, 0.975, 0.805, 0.95, 0.805, color=EDGE["g"])
ax.text(0.50, 0.83, "Writes replayed from the\nAzure blob access trace", ha="center", fontsize=6.5, color=MUTED)
arrow(ax, 0.40, 0.805, 0.32, 0.805, color=MUTED, ls="--")
save(fig, "fig1_architecture")

# ---------------- Fig. 2: per-slot workflow ----------------
fig, ax = plt.subplots(figsize=(7.48, 3.4))
ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")
FS = 6.8
row1 = [("1. Arrivals\nT1, commit, T2\nbits; streams", BLUE, EDGE["b"]),
        ("2. Key generation\nG(t) into pool P\n(capped at Bmax)", ORANGE, EDGE["o"]),
        ("3. Re-key floors\nT2 at L2,\nT3 at L1", GREY, EDGE["k"]),
        ("4. TKPF reserve\nforecast shortfall\n+ queued T1", PURPLE, EDGE["p"]),
        ("5. SLAS mode\nnormal or\ndegraded", PURPLE, EDGE["p"])]
row2 = [("6. KBRS\nT1 by earliest\ndeadline (OTP)", PURPLE, EDGE["p"]),
        ("7. Upgrades\nif P > reserve:\nT3 to L2, T2 OTP", PURPLE, EDGE["p"]),
        ("8. Use-or-lose\nspend key that\nwould overflow", GREY, EDGE["k"]),
        ("9. Deadlines\nT1 at age D\nsent with L2", GREEN, EDGE["g"]),
        ("10. Age queues\nmove to\nt + 1 s", GREY, EDGE["k"])]
w, h, gap = 0.17, 0.30, 0.0325
xs = [0.01 + i * (w + gap) for i in range(5)]
for i, (t, fc, ec) in enumerate(row1):
    box(ax, xs[i], 0.62, w, h, t, fc, ec, fs=FS)
    if i < 4:
        arrow(ax, xs[i] + w, 0.77, xs[i + 1], 0.77)
for i, (t, fc, ec) in enumerate(row2):
    j = 4 - i
    box(ax, xs[j], 0.10, w, h, t, fc, ec, fs=FS)
    if i < 4:
        arrow(ax, xs[j], 0.25, xs[j - 1] + w, 0.25)
arrow(ax, xs[4] + w / 2, 0.62, xs[4] + w / 2, 0.40)
arrow(ax, xs[0] + w / 2, 0.40, xs[0] + w / 2, 0.62, ls="--", color=MUTED)
ax.text(xs[0] + w / 2 + 0.008, 0.51, "next slot", fontsize=6.5, color=MUTED, ha="left", va="center")
save(fig, "fig2_workflow")
print(sorted(os.listdir(OUT)))
