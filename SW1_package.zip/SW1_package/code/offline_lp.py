"""Offline-optimal key allocation (upper bound), one LP per region link.

Minute-level relaxation with perfect knowledge of the whole trace:
L3 demand d1[m] (T1 payload + commit records) and T2 demand d2[m] may be
served by key spent in minute m or m+1 (relaxes the 60 s RPO), key pool
P[m] <= Bmax, mandatory re-key floors paid every minute. Objective
(lexicographic via weights): maximise 1000 * L3 OTP bits + T2 OTP bits.
Because the relaxation is looser than the 1-second simulation, its value
is an upper bound on what any online policy can reach.
"""
import numpy as np
import scipy.sparse as sp
from scipy.optimize import linprog
from sw1.sim import META_BITS, TAU_MIN, TAU_MAX


def lp_region(d1, d2, floor, G60, Bmax, P0):
    M = len(d1)
    # variable blocks: x1[m,0], x1[m,1], x2[m,0], x2[m,1], P[0..M]
    nX = 4 * M; nP = M + 1; N = nX + nP
    ix = lambda blk, m: blk * M + m
    iP = lambda m: nX + m
    c = np.zeros(N)
    c[ix(0, np.arange(M))] = -1000; c[ix(1, np.arange(M))] = -1000
    c[ix(2, np.arange(M))] = -1; c[ix(3, np.arange(M))] = -1
    rows, cols, vals, b = [], [], [], []
    r = 0
    # demand caps
    for blk_a, blk_b, d in ((0, 1, d1), (2, 3, d2)):
        for m in range(M):
            rows += [r, r]; cols += [ix(blk_a, m), ix(blk_b, m)]; vals += [1, 1]; b.append(d[m]); r += 1
    # spend in minute m: x?[m,0] + x?[m-1,1] + floor[m];  P[m+1] <= P[m] + G - spend ; spend <= P[m] + G
    for m in range(M):
        sp_idx = [ix(0, m), ix(2, m)] + ([ix(1, m - 1), ix(3, m - 1)] if m > 0 else [])
        # P[m+1] - P[m] + spend <= G - floor
        rows += [r] * (2 + len(sp_idx)); cols += [iP(m + 1), iP(m)] + sp_idx
        vals += [1, -1] + [1] * len(sp_idx); b.append(G60 - floor[m]); r += 1
        # spend - P[m] <= G - floor
        rows += [r] * (1 + len(sp_idx)); cols += [iP(m)] + sp_idx
        vals += [-1] + [1] * len(sp_idx); b.append(G60 - floor[m]); r += 1
    A = sp.csr_matrix((vals, (rows, cols)), shape=(r, N))
    bounds = [(0, None)] * nX + [(P0, P0)] + [(0, Bmax)] * M
    # x?[M-1,1] would spend after the horizon: forbid
    bounds[ix(1, M - 1)] = (0, 0); bounds[ix(3, M - 1)] = (0, 0)
    res = linprog(c, A_ub=A, b_ub=np.array(b), bounds=bounds, method="highs")
    if res.status != 0:
        return None
    x = res.x
    return float(x[:2 * M].sum()), float(x[2 * M:4 * M].sum())


def offline_bound_realised(A, real, G_bps, Bmax_s=600.0):
    """Bound on the exact realisation used by the simulation (seeded
    arrivals and jittered key generation), so it bounds that run."""
    floor = 256 * (A["s2"] / TAU_MIN + A["s3"] / TAU_MAX) * 60
    s1 = s2 = t1 = t2 = 0.0
    for r in range(real.shape[0]):
        d1, d2, g = real[r, :, 0], real[r, :, 1], real[r, :, 2]
        o = lp_region_g(d1, d2, np.minimum(floor[r], g), g, Bmax_s * G_bps, 0.5 * Bmax_s * G_bps)
        s1 += o[0]; s2 += o[1]; t1 += d1.sum(); t2 += d2.sum()
    return {"otp_cov_T1": s1 / t1, "otp_cov_T2": s2 / max(t2, 1)}


def lp_region_g(d1, d2, floor, g, Bmax, P0):
    """Same LP as lp_region but with per-minute key generation g[m]."""
    M = len(d1); nX = 4 * M; N = nX + M + 1
    ix = lambda blk, m: blk * M + m
    iP = lambda m: nX + m
    c = np.zeros(N)
    c[0:2 * M] = -1000; c[2 * M:4 * M] = -1
    rows, cols, vals, b = [], [], [], []; r = 0
    for blk_a, blk_b, d in ((0, 1, d1), (2, 3, d2)):
        for m in range(M):
            rows += [r, r]; cols += [ix(blk_a, m), ix(blk_b, m)]; vals += [1, 1]; b.append(d[m]); r += 1
    for m in range(M):
        sp_idx = [ix(0, m), ix(2, m)] + ([ix(1, m - 1), ix(3, m - 1)] if m > 0 else [])
        rows += [r] * (2 + len(sp_idx)); cols += [iP(m + 1), iP(m)] + sp_idx
        vals += [1, -1] + [1] * len(sp_idx); b.append(g[m] - floor[m]); r += 1
        rows += [r] * (1 + len(sp_idx)); cols += [iP(m)] + sp_idx
        vals += [-1] + [1] * len(sp_idx); b.append(g[m] - floor[m]); r += 1
    A_ = sp.csr_matrix((vals, (rows, cols)), shape=(r, N))
    bounds = [(0, None)] * nX + [(P0, P0)] + [(0, Bmax)] * M
    bounds[ix(1, M - 1)] = (0, 0); bounds[ix(3, M - 1)] = (0, 0)
    res = linprog(c, A_ub=A_, b_ub=np.array(b), bounds=bounds, method="highs")
    if res.status != 0:
        raise RuntimeError("LP failed")
    return float(res.x[:2 * M].sum()), float(res.x[2 * M:4 * M].sum())


def offline_bound(A, G_bps, Bmax_s=600.0):
    l3 = A["t1_bits"] + A["writes"] * META_BITS
    floor = 256 * (A["s2"] / TAU_MIN + A["s3"] / TAU_MAX) * 60
    tot1 = tot2 = s1 = s2 = 0.0
    for r in range(l3.shape[0]):
        G60 = G_bps * 60
        o = lp_region(l3[r], A["t2_bits"][r], np.minimum(floor[r], G60), G60, Bmax_s * G_bps, 0.5 * Bmax_s * G_bps)
        if o is None:
            raise RuntimeError(f"LP failed for region {r}")
        s1 += o[0]; s2 += o[1]; tot1 += l3[r].sum(); tot2 += A["t2_bits"][r].sum()
    return {"otp_cov_T1": s1 / tot1, "otp_cov_T2": s2 / max(tot2, 1)}


if __name__ == "__main__":
    import sys, time
    from sw1.sim import load
    from sw1.qkd_link import decoy_key_rate
    _, A = load(10, int(sys.argv[1]) if len(sys.argv) > 1 else 3)
    for L in (120.0, 140.0, 160.0):
        t0 = time.time()
        print(L, offline_bound(A, float(decoy_key_rate(L)[0])), f"{time.time()-t0:.0f}s", flush=True)
