"""Figs. 3-8 for Sub-work 1 from results/sw1_qkd_link.json and sw1_results.json."""
import json, os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

R = "/home/claude/hema/results"
OUT = "/home/claude/hema/sw1/figs"
q = json.load(open(f"{R}/sw1_qkd_link.json"))
d = json.load(open(f"{R}/sw1_results.json"))
C = {"Proposed": "#2a78d6", "FCFS (ETSI 014)": "#eb6834", "Static split": "#1baf7a",
     "Proposed w/o TKPF": "#eda100", "Offline optimum": "#52514e", "Proposed w/o KBRS": "#e87ba4",
     "Proposed w/o SLAS": "#4a3aa7"}
MK = {"Proposed": "o", "FCFS (ETSI 014)": "s", "Static split": "^", "Proposed w/o TKPF": "D", "Offline optimum": ""}
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8, "axes.edgecolor": "#52514e",
                     "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True,
                     "grid.color": "#e6e5e1", "grid.linewidth": 0.6, "legend.frameon": False,
                     "lines.linewidth": 1.6, "lines.markersize": 4.5, "xtick.color": "#52514e",
                     "ytick.color": "#52514e"})


def save(fig, name):
    fig.tight_layout()
    fig.savefig(f"{OUT}/{name}.png", dpi=600)
    fig.savefig(f"{OUT}/{name}.pdf")
    fig.savefig(f"{OUT}/{name}.tiff", dpi=1000, pil_kwargs={"compression": "tiff_lzw"})
    plt.close(fig)


def lab(ax, t):
    ax.text(0.0, 1.03, t, transform=ax.transAxes, fontsize=9, fontweight="bold", va="bottom", ha="right")


# ---- Fig. 3: key rate and QBER vs distance ----
fig, (a, b) = plt.subplots(1, 2, figsize=(7.48, 2.8))
L = [m["dist_km"] for m in q["model"]]
a.semilogy(L, [max(m["skr_bps"], 1e-1) for m in q["model"]], color=C["Proposed"], label="Secret key rate (decoy-state bound)")
a.semilogy([s["dist_km"] for s in q["seq"]], [s["sifted_bps"] for s in q["seq"]], "s", color=C["FCFS (ETSI 014)"],
           label="Sifted rate (SeQUeNCe, 80 MHz source)")
a.axvline(d["L_main"], color="#52514e", lw=0.8, ls="--")
a.text(d["L_main"] + 3, 2e6, f"main setting\n{d['L_main']:.0f} km", fontsize=7, color="#52514e")
a.set_xlabel("Fibre length (km)"); a.set_ylabel("Rate (bit/s)"); a.set_ylim(1e2, 5e7); a.legend(fontsize=7, loc="lower left")
lab(a, "(a)")
b.plot(L, [100 * m["qber"] for m in q["model"]], color=C["Proposed"], label="Model QBER (e_d = 1%)")
b.plot([s["dist_km"] for s in q["seq"]], [100 * s["qber"] for s in q["seq"]], "s", color=C["FCFS (ETSI 014)"],
       label="SeQUeNCe QBER")
b.set_xlabel("Fibre length (km)"); b.set_ylabel("QBER (%)"); b.set_ylim(0, 6); b.legend(fontsize=7, loc="upper left")
lab(b, "(b)")
save(fig, "fig3_keyrate")

# ---- Fig. 4: main comparison ----
pols = ["Proposed", "Proposed w/o KBRS", "Proposed w/o TKPF", "Proposed w/o SLAS", "FCFS (ETSI 014)", "Static split"]
short = ["Proposed", "w/o KBRS", "w/o TKPF", "w/o SLAS", "FCFS", "Static"]
m = {p: [r for r in d["main"] if r["policy"] == p] for p in pols}
fig, (a, b) = plt.subplots(1, 2, figsize=(7.48, 2.7))
y = [100 * np.mean([r["otp_cov_T1"] for r in m[p]]) for p in pols]
e = [100 * np.std([r["otp_cov_T1"] for r in m[p]]) for p in pols]
cols = [C["Proposed"]] + ["#86b6ef"] * 3 + [C["FCFS (ETSI 014)"], C["Static split"]]
a.bar(range(6), y, yerr=e, color=cols, width=0.7, capsize=2, error_kw={"lw": 0.8})
a.axhline(100 * d["offline_main"]["otp_cov_T1"], color="#52514e", ls="--", lw=0.9)
a.text(5.45, 100 * d["offline_main"]["otp_cov_T1"] + 1.5, "offline optimum", ha="right", fontsize=7, color="#52514e")
a.set_xticks(range(6), short, rotation=25, ha="right"); a.set_ylabel("OTP coverage of T1 + commit bits (%)")
a.set_ylim(0, 105); a.grid(axis="x", visible=False); lab(a, "(a)")
y = [np.mean([r["viol_per_hour"] for r in m[p]]) for p in pols]
e = [np.std([r["viol_per_hour"] for r in m[p]]) for p in pols]
b.bar(range(6), y, yerr=e, color=cols, width=0.7, capsize=2, error_kw={"lw": 0.8})
b.set_xticks(range(6), short, rotation=25, ha="right"); b.set_ylabel("Floor-violation seconds per hour")
b.grid(axis="x", visible=False); lab(b, "(b)")
save(fig, "fig4_main")

# ---- Fig. 5: one day of the busiest T1 region ----
tm = d["trace_minute"]
day = 4
sl = slice(day * 1440, (day + 1) * 1440)
hrs = np.arange(1440) / 60
fig, (a, b) = plt.subplots(2, 1, figsize=(7.48, 4.2), sharex=True, gridspec_kw={"height_ratios": [1, 1.3], "hspace": 0.45})
arr = np.array(tm["Proposed"]["l3_arrival_bps"][sl]).reshape(-1, 5).mean(1) / 1e3
a.fill_between(np.arange(len(arr)) * 5 / 60, arr, step="post", color="#b5b4ae", lw=0, label="T1 + commit demand (5-min mean)")
a.axhline(d["main"][0]["key_rate_bps"] / 1e3, color=C["FCFS (ETSI 014)"], ls="--", lw=1.0, label="QKD secret-key rate")
a.set_ylabel("kbit/s"); a.set_ylim(0, max(arr.max(), 40) * 1.25)
a.legend(fontsize=7, loc="upper left", bbox_to_anchor=(0.0, 1.32), ncol=2); lab(a, "(a)")
for p in ("Proposed", "FCFS (ETSI 014)", "Static split"):
    b.plot(hrs, np.array(tm[p]["pool_bits"][sl]) / 1e6, color=C[p], lw=1.0, label=f"Pool, {p.split(' (')[0]}")
b.plot(hrs, np.array(tm["Proposed"]["reserve_bits"][sl]) / 1e6, color=C["Proposed"], ls=":", lw=1.0, label="TKPF reserve")
b.set_ylabel("Key pool (Mbit)"); b.set_xlabel(f"Hour of day {day + 1} (region iic)")
b.legend(fontsize=7, loc="upper left", bbox_to_anchor=(0.0, 1.28), ncol=4); lab(b, "(b)")
b.set_ylim(0, 1.12 * max(np.array(tm["Proposed"]["pool_bits"]).max(), 1) / 1e6)
save(fig, "fig5_timeseries")

# ---- Fig. 6: OTP coverage vs distance ----
fig, (a, b) = plt.subplots(1, 2, figsize=(7.48, 2.8))
for p in ("Static split", "FCFS (ETSI 014)", "Proposed w/o TKPF", "Proposed", "Offline optimum"):
    rs = sorted([r for r in d["distance"] if r["policy"] == p and r["L_km"] >= 100], key=lambda r: r["L_km"])
    ls = "--" if p == "Offline optimum" else "-"
    a.plot([r["L_km"] for r in rs], [100 * r["otp_cov_T1"] for r in rs], ls=ls, marker=MK.get(p, ""), color=C[p],
           label=p.replace(" (ETSI 014)", ""), lw=1.2 if p == "Offline optimum" else 1.6, zorder=5 if p == "Offline optimum" else 3)
    if p != "Offline optimum":
        b.semilogy([r["L_km"] for r in rs], [max(r["viol_per_hour"], 0.01) for r in rs], marker=MK.get(p, ""), color=C[p],
                   label=p.replace(" (ETSI 014)", ""))
a.set_xlabel("Fibre length (km)"); a.set_ylabel("T1 + commit OTP coverage (%)"); a.legend(fontsize=7, loc="lower left"); lab(a, "(a)")
b.set_xlabel("Fibre length (km)"); b.set_ylabel("Floor-violation seconds per hour"); b.set_ylim(0.1, 5e3); lab(b, "(b)")
b.legend(fontsize=7, loc="lower right")
save(fig, "fig6_distance")

# ---- Fig. 7: sensitivity ----
S = d["sens"]
fig, ax = plt.subplots(1, 3, figsize=(7.48, 2.9))
for p in ("Proposed", "FCFS (ETSI 014)"):
    rs = [r for r in S if r["factor"] == "Bmax_s" and r["policy"] == p]
    ax[0].semilogx([r["value"] for r in rs], [100 * r["otp_cov_T1"] for r in rs], marker=MK[p], color=C[p], label=p.replace(" (ETSI 014)", ""))
ax[0].set_xlabel("Key pool size (s of generation)"); ax[0].set_ylabel("T1 + commit OTP coverage (%)"); ax[0].legend(fontsize=7); lab(ax[0], "(a)")
rs = [r for r in S if r["factor"] == "H"]
xh = np.arange(len(rs))
ax[1].plot(xh, [100 * r["otp_cov_T1"] for r in rs], marker="o", color=C["Proposed"], label="OTP coverage")
ax[1].set_xticks(xh, [f"{r['value']:.0f}" for r in rs]); ax[1].set_xlabel("TKPF horizon H (s)"); ax[1].set_ylabel("OTP coverage (%)")
t = ax[1].twinx(); t.spines["right"].set_visible(True); t.grid(False)
t.plot(xh, [r["switches_per_hour"] for r in rs], marker="s", ls="--", color="#52514e", label="Mode switches")
t.set_ylabel("Switches per hour"); lab(ax[1], "(b)")
h1, l1 = ax[1].get_legend_handles_labels(); h2, l2 = t.get_legend_handles_labels(); ax[1].legend(h1 + h2, l1 + l2, fontsize=6.5, loc="upper center", bbox_to_anchor=(0.5, -0.27), ncol=2)
for p in ("Proposed", "FCFS (ETSI 014)", "Static split"):
    rs = [r for r in S if r["factor"] == "key_scale" and r["policy"] == p]
    ax[2].plot([r["value"] for r in rs], [100 * r["otp_cov_T1"] for r in rs], marker=MK[p], color=C[p], label=p.replace(" (ETSI 014)", ""))
ax[2].set_xlabel("Key-rate scale factor"); ax[2].set_ylabel("OTP coverage (%)"); ax[2].legend(fontsize=6.5); lab(ax[2], "(c)")
fig.subplots_adjust(left=0.07, right=0.985, bottom=0.30, top=0.90, wspace=0.80)
fig.savefig(f"{OUT}/fig7_sensitivity.png", dpi=600); fig.savefig(f"{OUT}/fig7_sensitivity.pdf")
fig.savefig(f"{OUT}/fig7_sensitivity.tiff", dpi=1000, pil_kwargs={"compression": "tiff_lzw"}); plt.close(fig)

# ---- Fig. 8: lag distribution and deferral trade-off ----
fig, (a, b) = plt.subplots(1, 2, figsize=(7.48, 2.8))
for p in ("Proposed", "FCFS (ETSI 014)", "Static split"):
    h = np.array([r for r in d["main"] if r["policy"] == p and r["seed"] == 1][0]["lag1_hist"])
    c = np.cumsum(h) / h.sum()
    a.step(np.arange(len(c)), 100 * c, where="post", color=C[p], label=p.replace(" (ETSI 014)", ""))
a.set_xlabel("Wait for OTP key, T1 + commit bits (s)"); a.set_ylabel("Cumulative share of bits (%)")
a.set_xlim(-1, 61); a.legend(fontsize=7, loc="lower right"); lab(a, "(a)")
for L, ls in ((60.0, ":"), (100.0, "--"), (140.0, "-")):
    rs = sorted([r for r in d["defer"] if r["policy"] == "Proposed" and r["L_km"] == L], key=lambda r: r["W2"])
    b.plot([r["lag_T2_mean_s"] for r in rs], [100 * r["otp_cov_T2"] for r in rs], ls=ls, marker="o", color=C["Proposed"],
           label=f"{L:.0f} km")
b.set_xlabel("Mean added replication lag, T2 (s)"); b.set_ylabel("T2 OTP coverage (%)"); b.legend(fontsize=7, title="Proposed", title_fontsize=7)
lab(b, "(b)")
save(fig, "fig8_lag_defer")
print("ok")
